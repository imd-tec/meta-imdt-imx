constexpr int kErrorBaseBle = -1000;
constexpr int kErrorBaseWifi = -2000;

enum class BluetoothTestError : int
{
   kBluetoothOk = 0,
   kBluetoothAttachError = kErrorBaseBle,
   kBluetoothInstallError,
   kBluetoothInitializeError,
   kBluetoothCheckRunningError,
   kBluetoothRetrieveVersionError
};

enum class WifiMode : int
{
    kOff = 0,
    kAccessPoint,
    kStation,
    kError
};

enum class WifiTestError : int
{
    kWifiOk = 0,
    kAccessPointModeCheckingError = kErrorBaseWifi,
    kStationModeCheckingError,
    kCreateAccessPointError, 
    kCreateStationError, 
    kDisableWifiError, 
    kRetrieveNoApClientsError,
    kChangeApCredentialsError,
    kPingAddressError,
    kWifiModeSetError,
};

enum class ResultState
{
    kSuccess,
    kFailure,
    kFinished,
    kSkipped
};