#include <iostream>
#include <string.h>
#include <unistd.h>
#include "pico-production-test.h"
#include <vector>
#include <string>
#include <algorithm>
#include "version.hpp"

static std::vector<std::string> kWifiModeStringList = {"OFF", "AP", "STA"};

constexpr const char *kWifiTestUsage = 
"Usage: pico-production-wifi-test <Test mode> <Parameter 1> <Parameter 2> <Parameter 3>\n\n"
"Test mode: STA for station, AP for access point, OFF for off\n\n"
"Parameter 1: If the test mode is STA, parameter 1 should be the network name to connect to\n"
"             If the test mode is AP, parameter 1 should be the new temporary network name that is changed to during the test\n"
"             If the test mode is OFF, parameter 1 will be ignored\n\n"

"Parameter 2: If the test mode is STA, parameter 2 should be the password to connect to\n"
"             If the test mode is AP, parameter 2 should be the new temporary password that is changed to during the test\n"
"             If the test mode is OFF, parameter 2 will be ignored\n\n"
                        
"Parameter 3: If the test mode is STA, parameter 3 should be the address to ping to\n"
"             If the test mode is AP, parameter 3 will be ignored\n"
"             If the test mode is OFF, parameter 3 will be ignored\n\n"

"If the test mode is STA or AP, parameter 1,2 and 3 can be empty and the wifi would switch into STA or AP mode with previous network name and password settings\n";

struct WifiCommand
{
   std::string command_string;
   WifiMode mode;
   WifiTestError err;
   int timeout;
   bool has_args;
   std::vector<int> user_parameter_array;
   std::string msg= "";
};

static std::vector<WifiCommand> kWifiSetMode =
{
   {"/opt/imdt/wifi/create-access-point.sh",            WifiMode::kAccessPoint,             WifiTestError::kCreateAccessPointError, 0, false, {0}},
   {"/opt/imdt/wifi/connect-to-access-point.sh",        WifiMode::kStation,         WifiTestError::kCreateStationError, 0, false, {0}},
   {"/opt/imdt/wifi/disable-wifi.sh",                   WifiMode::kOff,                 WifiTestError::kDisableWifiError, 0, false, {0}}
};

static std::vector<WifiCommand> kWifiGetMode =
{
   {"systemctl is-active hostapd.service --quiet",                              WifiMode::kAccessPoint,     WifiTestError::kAccessPointModeCheckingError, 0, false, {0}},
   {"systemctl is-active wpa_supplicant-nl80211@wlan0.service --quiet",         WifiMode::kStation,         WifiTestError::kStationModeCheckingError, 0, false, {0}}
};

static std::vector<WifiCommand> kWifiAccessPointTest=
{
   {"/opt/imdt/wifi/get-number-of-ap-clients.sh",                       WifiMode::kAccessPoint,     WifiTestError::kRetrieveNoApClientsError, 0, false, {0}},
   {"/opt/imdt/wifi/disable-wifi.sh",                                   WifiMode::kAccessPoint,     WifiTestError::kDisableWifiError, 0, false, {0}},
   {"/opt/imdt/wifi/create-access-point.sh",                            WifiMode::kAccessPoint,     WifiTestError::kCreateAccessPointError, 0, false, {0}},
   {"/opt/imdt/wifi/get-number-of-ap-clients.sh",                       WifiMode::kAccessPoint,     WifiTestError::kRetrieveNoApClientsError, 0, false, {0}},
   {"/opt/imdt/wifi/create-access-point.sh ",                           WifiMode::kAccessPoint,     WifiTestError::kChangeApCredentialsError, 65, true, {2, 3}, "Please connect to the access point once again using the latest credentials..."},
   {"/opt/imdt/wifi/get-number-of-ap-clients.sh",                       WifiMode::kAccessPoint,     WifiTestError::kRetrieveNoApClientsError, 0, false, {0}},
   {"/opt/imdt/wifi/disable-wifi.sh",                                   WifiMode::kAccessPoint,     WifiTestError::kDisableWifiError, 0, false, {0}},
   {"/opt/imdt/wifi/create-access-point.sh imdt-pico imdtpico2022",     WifiMode::kAccessPoint,     WifiTestError::kChangeApCredentialsError, 0, false, {0}},   
};

static std::vector<WifiCommand> kWifiStationTest=
{
   {"/opt/imdt/wifi/connect-to-access-point.sh ",                       WifiMode::kStation,     WifiTestError::kCreateAccessPointError, 0, true, {2, 3}},
   {"ping -c 2 ",                                                       WifiMode::kStation,     WifiTestError::kPingAddressError, 0, true, {4}}
};

static ResultState RunCommand(WifiCommand cmd, WifiTestError &status)
{
    int result = 0;
    if (status == WifiTestError::kWifiOk)
    {
        std::string wifi_command;
        wifi_command = cmd.command_string + " > /dev/null";
        result = system(wifi_command.c_str());
        if (WIFEXITED(result) != true)
        {
            status = cmd.err;
            return ResultState::kFailure;
        }
        else if (WEXITSTATUS(result) == 0)
        {
            return ResultState::kSuccess;
        }
        return ResultState::kFinished;
    }
    return ResultState::kSkipped;
}

static WifiMode SetWifiMode(int user_wifi_mode, WifiTestError &status)
{
    ResultState result;
    for (WifiCommand &cmd : kWifiSetMode)
    {
        if (user_wifi_mode == static_cast<int>(cmd.mode))
        {
            result = RunCommand(cmd, status);
            if (((result == ResultState::kSuccess) || (result == ResultState::kFinished)) && (status == WifiTestError::kWifiOk))
            {
                return cmd.mode;
            }
        }
    }
    status = (status == WifiTestError::kWifiOk) ? WifiTestError::kWifiModeSetError : status;
    return WifiMode::kError;
}

static WifiMode GetWifiMode(WifiTestError &status)
{
    ResultState result;
    for (WifiCommand &cmd : kWifiGetMode)
    {
        result = RunCommand(cmd, status);
        if (result == ResultState::kSuccess)
        {
            return cmd.mode;
        }
        else if (result == ResultState::kFailure)
        {
            return WifiMode::kError;
        }
    }
    return WifiMode::kOff;
}

static WifiTestError RunWifiTest(std::vector<WifiCommand>& cmd_run_list, char *command_args[], WifiTestError &status)
{
    ResultState result;
    for (WifiCommand& cmd : cmd_run_list)
    {
        std::string command_string = cmd.command_string;
        if (cmd.has_args)
        {
            for (int i : cmd.user_parameter_array)
            {
                command_string += command_args[i];
                command_string += " ";
            }
        }
        WifiCommand wifi_command_appended = cmd;
        wifi_command_appended.command_string = command_string;
        result = RunCommand(wifi_command_appended, status);
        if ((result == ResultState::kFinished) || (result == ResultState::kFailure))
        {
            status = cmd.err;
        }
        if ((cmd.msg.compare("") != 0) && (status == WifiTestError::kWifiOk))
        {
            std::cout << cmd.msg << std::endl;
        }
        sleep(cmd.timeout);
    }
    return status;
}

int main(int argc, char *argv[])
{
    WifiTestError status = WifiTestError::kWifiOk;
    WifiMode wifi_mode = WifiMode::kOff;
    int user_wifi_mode = 0;
    if (argc < 2)
    {
        std::cout << kWifiTestUsage << std::endl;
        return 1;
    }

    auto it = std::find(kWifiModeStringList.begin(), kWifiModeStringList.end(), argv[1]);
    if (it != kWifiModeStringList.end()) {
        user_wifi_mode = std::distance(kWifiModeStringList.begin(), it);
    }
    else
    {
        std::cout << kWifiTestUsage << std::endl;
        return 1;
    }

    if(((wifi_mode = SetWifiMode(user_wifi_mode, status)) != GetWifiMode(status)) && (status == WifiTestError::kWifiOk)) 
    {
        status = WifiTestError::kWifiModeSetError;
    }

    if ((wifi_mode == WifiMode::kAccessPoint) && (argc == 4))
    {
        RunWifiTest(kWifiAccessPointTest, argv, status);
    }
    else if ((wifi_mode == WifiMode::kStation) && (argc == 5))
    {
        RunWifiTest(kWifiStationTest, argv, status);
    }
    else
    {
        std::cout << kWifiTestUsage << std::endl;
        return 1;
    }

    std::cout << IMDT_PRODUCTION_PROJECT_NAME << ": " << argv[1] << " Wifi test v" << IMDT_PRODUCTION_VERSION << " finished (" << static_cast<int>(status) << ")" << std::endl;
    return static_cast<int>(status);
}

