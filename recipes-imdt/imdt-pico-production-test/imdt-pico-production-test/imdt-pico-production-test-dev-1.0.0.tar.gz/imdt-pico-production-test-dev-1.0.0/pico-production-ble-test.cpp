#include <iostream>
#include "pico-production-test.h"
#include <sstream>
#include "version.hpp"

struct BluetoothCommand
{
   std::string command;
   BluetoothTestError err;
};

BluetoothCommand kBluetoothPreTest[] =
{
   {"hciconfig | grep \"hci0\"",        BluetoothTestError::kBluetoothInstallError},
   {"hciconfig | grep \"UP RUNNING\"",  BluetoothTestError::kBluetoothCheckRunningError},
   {"hciconfig hci0 version",           BluetoothTestError::kBluetoothRetrieveVersionError},
};

BluetoothCommand kBluetoothTest[] =
{
   "hciattach /dev/ttymxc0 bcm43xx", BluetoothTestError::kBluetoothAttachError,
   "hciconfig | grep \"hci0\"", BluetoothTestError::kBluetoothInstallError,
   "hciconfig hci0 up", BluetoothTestError::kBluetoothInitializeError,
   "hciconfig | grep \"UP RUNNING\"", BluetoothTestError::kBluetoothCheckRunningError,
   "hciconfig hci0 version", BluetoothTestError::kBluetoothRetrieveVersionError,
};

static ResultState RunCommand(std::string command, BluetoothTestError &status)
{
   int result = 0;
   if (status == BluetoothTestError::kBluetoothOk)
   {
      std::ostringstream oss;
      oss << command << " > /dev/null";
      result = system(oss.str().c_str());
      if ((WIFEXITED(result) == true) && (WEXITSTATUS(result) == 0)) 
      {
         return ResultState::kSuccess;
      }
      else
      {
         return ResultState::kFailure;
      }
   }
   return ResultState::kSkipped;
}

int main(int argc, char *argv[])
{
   BluetoothTestError status = BluetoothTestError::kBluetoothOk;

   for (BluetoothCommand &cmd : kBluetoothPreTest)
   {
      status = (RunCommand(cmd.command, status) == ResultState::kFailure) ? cmd.err : status;
   }

   if (status == BluetoothTestError::kBluetoothOk)
   {
      std::cout << IMDT_PRODUCTION_PROJECT_NAME << ": Bluetooth test v" << IMDT_PRODUCTION_VERSION << " finished (" << static_cast<int>(status) << ")" << std::endl;
      return static_cast<int>(status);
   }
   else if (status != BluetoothTestError::kBluetoothRetrieveVersionError)
   {
      status = BluetoothTestError::kBluetoothOk;
   }

   for (BluetoothCommand &cmd : kBluetoothTest)
   {
      status = (RunCommand(cmd.command, status) == ResultState::kFailure) ? cmd.err : status;
   }

   std::cout << IMDT_PRODUCTION_PROJECT_NAME << ": Bluetooth test v" << IMDT_PRODUCTION_VERSION << " finished (" << static_cast<int>(status) << ")" << std::endl;
   return static_cast<int>(status);
}
