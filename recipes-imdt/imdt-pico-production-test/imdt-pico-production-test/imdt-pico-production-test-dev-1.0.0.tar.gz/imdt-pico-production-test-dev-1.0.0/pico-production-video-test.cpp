#include <iostream>
#include <glib-2.0/glib.h>
#include <gstreamer-1.0/gst/gst.h>
#include <gstreamer-1.0/gst/app/gstappsink.h>
#include <unistd.h>
#include <opencv2/opencv.hpp>
#include <fstream>
#include <sys/stat.h>
#include <stdexcept>
#include "version.hpp"

//When ENABLE_PITCH_BLACK_TEST is 1, OpenCV is used to generate a pitch-black picture
//Instead of using /dev/video3 as the source of the pipeline to take a snapshot (When ENABLE_PITCH_BLACK_TEST is 0),
//The pitch-black picture generated is used as the source
//This is to confirm that the test will fail when verifying if each split color channel contains only zeros
//after splitting the captured frame into its constituent color channels
#ifndef ENABLE_PITCH_BLACK_TEST
#define ENABLE_PITCH_BLACK_TEST 0
#endif
#if ENABLE_PITCH_BLACK_TEST
const std::string kFPathBlackFilePath = "/pico-production-test/pitch-black.raw";
const std::string kGStreamerCommand = "multifilesrc location=/pico-production-test/pitch-black.raw ! rawvideoparse format=rgb width=1920 height=1080 ! videoconvert ! appsink name=sink";
#else
const std::string kGStreamerCommand = "v4l2src device=/dev/video3 num-buffers=1 ! video/x-raw, format=RGB, width=1920, height=1080 ! appsink name=sink";
#endif

const std::string kVideoDevicePath = "/dev/video3";
const int kExpectedWidth = 1920;
const int kExpectedHeight = 1080;
const int kBytesPerPixel = 3;

void gst_check_state(GstElement **pipeline, GstElement **sink, GError **pipeline_error, GstBuffer **buffer, GstMapInfo map, GstSample **sample)
{
    if ((*pipeline_error != nullptr))
    {
        g_error_free(*pipeline_error);
    }

    if ((*sink != nullptr) && (GST_IS_OBJECT(*sink)))
    {
        gst_object_unref(*sink);
    }

    if (*pipeline != nullptr)
    {
        GstState state;
        GstStateChangeReturn ret = gst_element_get_state(*pipeline, &state, nullptr, GST_CLOCK_TIME_NONE);
        if (ret == GST_STATE_CHANGE_SUCCESS) 
        {
            if (state != GST_STATE_NULL) 
            {
                gst_element_set_state(*pipeline, GST_STATE_NULL);
            }
        }
        if (GST_IS_OBJECT(*pipeline)) 
        {
            gst_object_unref(*pipeline);
        }
    }

    if (*buffer != nullptr)
    {
        gst_buffer_unmap(*buffer, &map);
    }

    if (*sample != nullptr)
    {
        gst_sample_unref(*sample);
    }

    *pipeline_error = nullptr;
    *pipeline = nullptr;
    *sink = nullptr;
    *buffer = nullptr;
    *sample = nullptr;
}

bool IsVideoDevicePresent(const char* device_path)
{
    struct stat file_stat;
    return (stat(device_path, &file_stat) == 0);
}

int main(int argc, char *argv[])
{
    GstElement *pipeline = nullptr;
    GstElement *sink = nullptr;
    GError *pipeline_error = nullptr;
    GstSample *sample = nullptr;
    GstBuffer *buffer = nullptr;
    GstMapInfo map;
    std::string gstreamer_error_message;
    try
    {

#if ENABLE_PITCH_BLACK_TEST

        if ((access(kFPathBlackFilePath.c_str(), F_OK) == 0) && (remove(kFPathBlackFilePath.c_str()) != 0))
        {
            throw std::runtime_error("Error with trying to remove the previous pitch-black picture file");
        }
        // Create a pitch-black image using OpenCV
        cv::Mat black_image = cv::Mat::zeros(kExpectedHeight, kExpectedWidth, CV_8UC3); // Create a black image (RGB888)
        // Save the image data to a raw file
        std::ofstream pitch_black_file(kFPathBlackFilePath.c_str(), std::ios::out | std::ios::binary);
        if (!pitch_black_file.is_open()) {
            throw std::runtime_error("Error opening file for writing");
        }
        pitch_black_file.write(reinterpret_cast<const char*>(black_image.data), kExpectedWidth * kExpectedHeight * 3); // Write pitch-black image data to the file

#else

        if (!IsVideoDevicePresent(kVideoDevicePath.c_str())) 
        {
            throw std::runtime_error("Video Device is not present");
        }

#endif

        // Initialize GStreamer
        gst_init(&argc, &argv);
        pipeline = gst_parse_launch_full(kGStreamerCommand.c_str(), NULL, GST_PARSE_FLAG_NONE, &pipeline_error); 
        if (pipeline_error != NULL) 
        {
            gstreamer_error_message = "Error during pipeline creation: ";
            gstreamer_error_message += pipeline_error->message;
            throw std::runtime_error(gstreamer_error_message);
        }
        sink = gst_bin_get_by_name(GST_BIN(pipeline), "sink");

        // Start pipeline
        GstStateChangeReturn ret = gst_element_set_state(pipeline, GST_STATE_PLAYING);
        if (ret == GST_STATE_CHANGE_FAILURE)
        {
            gstreamer_error_message = "Unable to set the pipeline to the playing state";
            throw std::runtime_error(gstreamer_error_message);
        }

        sample = gst_app_sink_pull_sample(GST_APP_SINK(sink));
        buffer = gst_sample_get_buffer(sample);
        
        gst_buffer_map(buffer, &map, GST_MAP_READ);
        cv::Mat frame(cv::Mat(cv::Size(1920, 1080), CV_8UC3, map.data));
        std::vector<cv::Mat> channels;
        cv::split(frame, channels); // Split the captured frame into its constituent color channels using OpenCV's 'split()' function

        // Verify if each split color channel contains only zeros, determining whether the snapshot is entirely pitch-black
        if (cv::countNonZero(channels[0]) == 0 &&
            cv::countNonZero(channels[1]) == 0 &&
            cv::countNonZero(channels[2]) == 0) 
        {
            throw std::runtime_error("Snapshot is pitch-black");
        }
        gst_check_state(&pipeline, &sink, &pipeline_error, &buffer, map, &sample);

#if ENABLE_PITCH_BLACK_TEST

        if ((access(kFPathBlackFilePath.c_str(), F_OK) == 0) && (remove(kFPathBlackFilePath.c_str()) != 0))
        {
            throw std::runtime_error("Error with trying to remove the pitch-black picture file");
        }

#endif

    }
    catch (const std::exception& e)
    {
        std::cerr << IMDT_PRODUCTION_PROJECT_NAME << ": Video test v" << IMDT_PRODUCTION_VERSION << " finished with exception: " << e.what() << std::endl;
        gst_check_state(&pipeline, &sink, &pipeline_error, &buffer, map, &sample);

#if ENABLE_PITCH_BLACK_TEST
        if ((access(kFPathBlackFilePath.c_str(), F_OK) == 0) && (remove(kFPathBlackFilePath.c_str()) != 0))
        {
            std::cerr << "Error with trying to remove the pitch-black picture file" << std::endl;
        }
#endif

        return 1;
    }
    std::cout << IMDT_PRODUCTION_PROJECT_NAME << ": Video test v" << IMDT_PRODUCTION_VERSION << " finished" << std::endl;
    return 0;
}
