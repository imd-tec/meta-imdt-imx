#include <iostream>
#include <vector>
#include <linux/i2c-dev.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdexcept>
#include "version.hpp"

const std::string kBus0 = "/dev/i2c-0";
const std::string kBus1 = "/dev/i2c-1";
const std::string kBus2 = "/dev/i2c-2";
const std::string kBus3 = "/dev/i2c-3";

const unsigned char kSlavePmic = 0x25;
const unsigned char kPmicChipIdBuffAddr = 0x00;
const unsigned char kPmicChipId = 0x31;

const unsigned char kSlaveMmc5633 = 0x30;
const unsigned char kMmc5633ChipIdBuffAddr = 0x39;
const unsigned char kMmc5633ChipId = 0x10;

const unsigned char kSlaveEeprom = 0x50;
const unsigned char kEepromBoardIdBuffAddr = 0x00;
const unsigned char kEepromBoardId = 0x03;

const unsigned char kSlaveAp1302 = 0x3C;
const unsigned char kAp1302Addr_H = 0x00;
const unsigned char kAp1302Addr_L = 0x00;
const unsigned char kAp1302ChipVersion_H = 0x02;
const unsigned char kAp1302ChipVersion_L = 0x65;

const unsigned char kSlaveCharger = 0x6B;
const unsigned char kChargerSysVoltBuffAddr = 0x0F;
const unsigned char kChargerSysVoltMin = 0x46;
const unsigned char kChargerSysVoltMax = 0x4A;

struct HwmonCommand
{
   std::string command_string;
};

struct I2cCommand
{
    std::string i2c_bus_device;
    unsigned char chip_addr;
    std::vector<unsigned char> tx_data;
    std::vector<unsigned char> expected_data;
};

static const std::vector<I2cCommand> kI2cTest =
{
    {kBus0, kSlavePmic,     {kPmicChipIdBuffAddr},                          {kPmicChipId}},                                     //PMIC Chip ID
  
    {kBus1, kSlaveMmc5633,  {kMmc5633ChipIdBuffAddr},                       {kMmc5633ChipId}},                                  //Magnetometer MMC5633 ChipID read

    {kBus2, kSlaveEeprom,   {kEepromBoardIdBuffAddr, kEepromBoardId},       {}},                                                //write board ID PCA-0003 to EEPROM
    {kBus2, kSlaveEeprom,   {kEepromBoardIdBuffAddr},                       {kEepromBoardId}},                                  //Read EEPROM

    {kBus3, kSlaveAp1302,   {kAp1302Addr_H, kAp1302Addr_L},                 {}},                                                //AP1302 Chip set data buffer address
    {kBus3, kSlaveAp1302,   {kAp1302Addr_H, kAp1302Addr_L},                 {kAp1302ChipVersion_H, kAp1302ChipVersion_L}}       //AP1302 Chip version read
};

static const std::vector<I2cCommand> kI2cChargerReadTest =
{
    {kBus1, kSlaveCharger,  {kChargerSysVoltBuffAddr},                      {kChargerSysVoltMin, kChargerSysVoltMax}}           //Charger Read Sys Voltage BQ25892    
};

static std::vector<HwmonCommand> kSht40Test =
{
    {"sensors | grep sht4x-i2c-1-44"},
    {"cat /sys/class/hwmon/hwmon1/name | grep sht4x"},
    {"cat /sys/class/hwmon/hwmon1/temp1_input | awk '{if ($1 > 85000) print \"Higher\"; else print \"Lower\"}' | grep Lower"},  //Between 0 to 85C
};

static void RunCommand(int i, std::string command)
{
    int result = 0;
    std::string appended_command = command + " > /dev/null";
    result = system(appended_command.c_str());
    if (!((WIFEXITED(result) == true) && (WEXITSTATUS(result) == 0)))
    {
        throw std::runtime_error("Failed to run the command " + std::to_string(i));
    }
}

static void HwmonSensorCheck(std::vector<HwmonCommand>& hwmon_array)
{
    for (size_t i = 0; i < hwmon_array.size(); i++)
    {
        RunCommand(i, hwmon_array[i].command_string);
    }
}

class I2cDevice
{
private:
    int fd = -1;
public:
    std::string i2c_bus_device;
    unsigned char chip_addr;

    I2cDevice(std::string i2c_bus_device, unsigned char chip_addr) : i2c_bus_device(i2c_bus_device), chip_addr(chip_addr)
    {       
        fd = open(i2c_bus_device.c_str(), O_RDWR);
        if (fd < 0)
        {
            throw std::runtime_error("Failed to open the file for the I2C bus " + i2c_bus_device);
        }
        if (ioctl(fd, I2C_SLAVE_FORCE, chip_addr) < 0) 
        {
            close(fd);
            throw std::runtime_error("Failed to select the i2c device " + i2c_bus_device + " " + std::to_string(chip_addr));
        }
    }
    void write(const std::vector<unsigned char>& i2c_write_buffer)
    {
        const unsigned char* write_data_ptr = i2c_write_buffer.data();
        if (::write(fd, write_data_ptr, i2c_write_buffer.size()) != static_cast<ssize_t>(i2c_write_buffer.size()))
        {
            throw std::runtime_error("Failed to write to the i2c device " + i2c_bus_device + " " + std::to_string(chip_addr));
        }
    }
    void read(std::vector<unsigned char>& read_buffer)
    {
        if (read_buffer.size() == 0) return;
        if (::read(fd, read_buffer.data(), read_buffer.size()) != static_cast<ssize_t>(read_buffer.size()))
        {
            throw std::runtime_error("Failed to read from the i2c device"  + i2c_bus_device + " " + std::to_string(chip_addr));
        }
    }
    ~I2cDevice()
    {
        if (fd != -1)
        {
            close(fd);
        }
    }
};

static void CompareI2cResultChargerVoltage(std::vector<unsigned char>& i2c_read_buffer, const std::vector<unsigned char>& i2c_result_buffer)
{
    if (i2c_result_buffer.size() == 0) return;
    if (!(i2c_read_buffer[0] >= i2c_result_buffer[0] && i2c_read_buffer[0] <= i2c_result_buffer[1]))
    {
        throw std::runtime_error("Charger Voltage result not in the range");
    }
}

static void CompareI2cResult(I2cDevice &device, std::vector<unsigned char>& i2c_read_buffer, const std::vector<unsigned char>& i2c_result_buffer)
{
    if (i2c_result_buffer.size() == 0) return;
    if (i2c_read_buffer != i2c_result_buffer)
    {
        throw std::runtime_error(device.i2c_bus_device + " " + std::to_string(device.chip_addr) + " Result not the same as expected");
    }
}

int main(int argc, char *argv[])
{
    std::vector<unsigned char> rx_buffer;
    try
    {
        HwmonSensorCheck(kSht40Test);
        for (const I2cCommand &cmd : kI2cTest)
        {
            rx_buffer.clear();
            rx_buffer.resize(cmd.expected_data.size());

            I2cDevice device(cmd.i2c_bus_device, cmd.chip_addr);
            device.write(cmd.tx_data);
            device.read(rx_buffer);

            CompareI2cResult(device, rx_buffer, cmd.expected_data);

            usleep(3000);
        }
        
        rx_buffer.clear();
        rx_buffer.resize(kI2cChargerReadTest[0].expected_data.size());

        I2cDevice device(kI2cChargerReadTest[0].i2c_bus_device, kI2cChargerReadTest[0].chip_addr);
        device.write(kI2cChargerReadTest[0].tx_data);
        device.read(rx_buffer);

        CompareI2cResultChargerVoltage(rx_buffer, kI2cChargerReadTest[0].expected_data);
    }
    catch (const std::exception& e) 
    {
        std::cerr << IMDT_PRODUCTION_PROJECT_NAME << ": I2C test v" << IMDT_PRODUCTION_VERSION << " finished with exception: " << e.what() << std::endl;
        return 1;
    }
    std::cout << IMDT_PRODUCTION_PROJECT_NAME << ": I2C test v" << IMDT_PRODUCTION_VERSION << " finished" << std::endl;
    return 0;
}
