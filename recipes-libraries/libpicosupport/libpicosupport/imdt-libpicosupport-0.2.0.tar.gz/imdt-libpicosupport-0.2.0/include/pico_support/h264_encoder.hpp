/**
 * @file h264_encoder.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Lewis Purvis <lewisp@imd-tec.com>
 */
#pragma once

#include <cstdint>
#include <cstddef>
#include <opencv2/opencv.hpp>
#include <imx-mm/vpu/vpu_wrapper.h>

namespace pico_support
{
    class H264Encoder;
    using H264EncoderSPtr = std::shared_ptr<H264Encoder>;
    enum class H264EncoderError;

    enum class EncoderInputVideoFormat
    {
        RGBA, YUV422
    };

    /**
     * @brief A library that uses the VPU to encode H264 frames.
     *
     */
    class H264Encoder
    {
    public:
        /**
         * @brief Construct a new H264Encoder object
         */
        H264Encoder();

    
        /**
         * @brief Opens the VPU encoder for a specified frame size, and frame rate
         *
         * @param width - in pixels, the input frame's horizontal resolution
         * @param height - in pixels, the input frame's vertical resolution
         * @param frame_rate - number of frames per second, the application requires of the encoder
         * @param input_format - the input data format to be encoded
         */
        void Open(const uint32_t width,
                  const uint32_t height,
                  const uint32_t frame_rate,
                  const EncoderInputVideoFormat input_format);

         /**
         * @brief Call this function to encode a single frame
         *
         * @pre The function Open() must be called before this function
         *
         * @param[in] frame Reference to the input opencv::Mat frame.
         * @param[in, out] out_buff pointer to the output buffer, to which the encoded frame shall be written
         * @param[in] out_buff_max_size Maximum size of the out_buff
         * @param[in] force_idr A boolean used to force the encoder to make this frame a reference frame (I frame).
         * @param[out] out_buff_offset The number of bytes the encoder has written to out_buff
         */
        uint32_t EncodeFrame(const cv::Mat& frame, uint8_t *out_buff, uint32_t out_buff_max_size, bool force_idr);
        
        
        /**
         * @brief Closes the VPU Encoder
         *
         */
        void Close();

       
         /**
         * @brief Accessor for Encoder picture Width in pixels
         * @pre Return value invalid unless Open() has previously been called
         * @return uint32_t Height
         */
        uint32_t GetWidth();

         /**
         * @brief Get Encoder picture Height in pixels
         * @pre Return value invalid unless Open() has previously been called
         * @return uint32_t Width
         */
        uint32_t GetHeight();

        /**
         * @brief Get Encoder frame rate
         * @pre Return value invalid unless Open() has previously been called
         * @return uint32_t Frame rate
         */
        uint32_t GetFrameRate();

        /**
         * @brief Get the Total number of frames the Encoder has processed since being opened
         * @pre return value only valid when the encoder is open
         * @return uint32_t Total number of frames encoded
         */
        uint32_t GetTotalFrames();

        /**
         * @brief Returns current state of the VPU Encoder
         * @return true if VPU encoder is open, false otherwise
         */
        bool IsVpuEncOpen();

        /**
         * @brief Get the Vpu Version Info object
         * 
         * @return const VpuVersionInfo& 
         */
        const VpuVersionInfo& GetVpuVersionInfo();

        /**
         * @brief Get the Vpu Wrapper Version Info object
         * 
         * @return const VpuWrapperVersionInfo& 
         */
        const VpuWrapperVersionInfo& GetVpuWrapperVersionInfo();

        /**
         * @brief Destroy the H264Encoder object
         */
        ~H264Encoder();


    private:
        // Defaults
        static constexpr uint32_t kDefaultBitrate = 0;
        static constexpr int32_t kDefaultGopSize = 30;
        static constexpr uint32_t kMaxInputWidth = 1920;
        static constexpr uint32_t kMaxInputHeight = 1080;
        static constexpr uint32_t kMaxFrameRate = 60;
        static constexpr int kDefaultH264Quant = 35;
        static constexpr int kDefaultForceIdr = 0;
        
        // state of VPU encoder
        bool _is_vpu_enc_open = false;

        EncoderInputVideoFormat _frame_input_format = EncoderInputVideoFormat::RGBA;
        // current frame in Group of Pictures
        uint32_t _gop_count = 0;
        // current size of Group of Pictures
        uint32_t _gop_size = kDefaultGopSize;
        // Total number of frames encoded since encoder was opened
        uint64_t _total_frames = 0;

        // VPU version info
        VpuVersionInfo _vpu_version_info;
        VpuWrapperVersionInfo _vpu_wrapper_info;

        // VPU's working memory
        VpuMemInfo _vpu_working_mem_info;           // VPU's base memory requirements - Read form VPU
        VpuMemDesc _vpu_working_mem_desc;           // description of the memory that has been allocated to the vpu as per the vpu_mem_info
        std::vector<uint8_t> _vpu_working_mem_virt; // vector of allocated virtual memory as per the vpu_mem_info

        // VPU encoder objects
        VpuEncOpenParamSimp _vpu_enc_params; // params given when opening encoder
        VpuEncHandle _vpu_enc_handle;        // handle returned once encoder open

        // VPU input buffer objects
        VpuFrameBuffer _vpu_input_frame_buffer; // contains meta data relating to the input buffer the encoder will read from
        VpuMemDesc _vpu_input_mem_desc;         // descriptor of physical memory assigned to the input buffer

        // initialises some member variables and reads static VPU data
        void Initialise();

        // Used to query and allocated the working memory the VPU encoder requires to operate
        void VpuQueryAllocMem();

        // Wraps up the initialisation/zeroing of some member variables
        void ResetMembersToDefault();
        // Called by Destructor,
        void DeInitialise();
    };

    inline uint32_t H264Encoder::GetWidth()
    {
        return static_cast<uint32_t>(_vpu_enc_params.nPicWidth);
    }

    inline uint32_t H264Encoder::GetHeight()
    {
        return static_cast<uint32_t>(_vpu_enc_params.nPicHeight);
    }

    inline uint32_t H264Encoder::GetFrameRate()
    {
        return static_cast<uint32_t>(_vpu_enc_params.nFrameRate);
    }

    inline uint32_t H264Encoder::GetTotalFrames()
    {
        return _total_frames;
    }

    inline bool H264Encoder::IsVpuEncOpen()
    {
        return _is_vpu_enc_open;
    }

    inline const VpuVersionInfo& H264Encoder::GetVpuVersionInfo()
    {
        return _vpu_version_info;
    }

    inline const VpuWrapperVersionInfo& H264Encoder::GetVpuWrapperVersionInfo()
    {
        return _vpu_wrapper_info;
    }


    /**
     * @brief H264Encoder exception
     */
    class H264EncoderException : public std::exception
    {
    public:
        /**
         * @brief Constructor
         * @param c Error code
         */
        H264EncoderException(const H264EncoderError c);

        /**
         * @brief Access the error code
         * @return
         */
        H264EncoderError code() const;

        /**
         * @brief Access a description of the exception
         * @return
         */
        const char *what() const noexcept
        {
            if (_error_descriptions.end() != _error_descriptions.find(_c))
            {
                return _error_descriptions[_c].c_str();
            }

            return "Unknown error";
        }

    private:
        /// @brief Error code
        H264EncoderError _c;

        static std::map<H264EncoderError, std::string> _error_descriptions;
    };

    inline H264EncoderException::H264EncoderException(const H264EncoderError c) : _c(c)
    {
    }

    inline H264EncoderError H264EncoderException::code() const
    {
        return _c;
    }

    enum class H264EncoderError
    {
        kInvalidCallWhenEncOpen,
        kInvalidCallWhenEncClosed,
        kFailedToLoadVpuEncoder,
        kFailedToGetVpuVerInfo,
        kFailedToGetVpuWrapperVerInfo,
        kFailedToQueryVpuMem,
        kFailedToAllocVpuVirtMem,
        kFailedToAllocVpuPhysMem,

        kEncOpenInvalidInputArgs,

        kFailedToOpenVpuEncoder,
        kFailedToConfigureVpu,
        kFailedToAllocInputPhysBuffer,

        kInputFrameResolutionMismatch,
        kInputFrameFormatMismatch,
        kEncFrameInvalidInputArgs,
        kFailedToEncodeFrame,

        kFailedToCloseVpu,
        kFailedToUnloadEncoder,
        kFailedToFreeEncInputPhysMem,
        kFailedToFreeEncWorkingPhysMem
    };
}
