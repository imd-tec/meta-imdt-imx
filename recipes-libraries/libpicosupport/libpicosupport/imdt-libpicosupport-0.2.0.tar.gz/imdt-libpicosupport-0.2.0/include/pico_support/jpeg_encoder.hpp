/**
 * @file jpeg_encoder.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include <turbojpeg.h>

#include <cstdint>
#include <cstddef>
#include <string>

namespace pico_support
{
    /**
     * @brief JPEG image
     */
    struct JPEGImage
    {
        /**
         * @brief Pointer to the buffer containing the image
         * @details This will be dynamically-allocated by the JPEGEncoder class
         */
        uint8_t *data;

        /**
         * @brief Size of the buffer in bytes
         */
        size_t size;
    };

    /**
     * @brief Wrapper for the TurboJPEG library
     */
    class JPEGEncoder
    {
    public:

        /**
         * @brief Create a TurboJPEG compressor instance
         */
        JPEGEncoder();

        /**
         * @brief Destroy the TurboJPEG instance
         */
        ~JPEGEncoder();

        /**
         * @brief Encode an RGB image as a JPEG
         * @param data Pointer to the RGB image data
         * @param width Image width
         * @param height Image height
         * @return JPEGImage object
         */
        JPEGImage Encode(uint8_t *data, uint32_t width, uint32_t height);

        /**
         * @brief Write the JPEG image to disk
         * @param filename Output file name
         * @param jpegImage The JPEGImage object
         */
        void Save(const std::string& filename, JPEGImage jpeg_image);

        /**
         * @brief Free the buffer associated with a JPEGImage object
         * @param jpeg_image The JPEGImage object
         */
        void FreeBuffer(JPEGImage& jpeg_image);

    private:

        /// @brief TurboJPEG compressor instance
        tjhandle _instance { nullptr };

    };
}
