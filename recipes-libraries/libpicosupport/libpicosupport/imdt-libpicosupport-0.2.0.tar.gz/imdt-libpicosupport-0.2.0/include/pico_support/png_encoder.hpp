/**
 * @file png_encoder.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include <png.h>

#include <cstdint>
#include <cstddef>
#include <string>

namespace pico_support
{
    /**
     * @brief Wrapper for the PNG library
     */
    class PNGEncoder
    {
    public:

        /**
         * @brief Encode an RGB image as a PNG
         * @param filename Output file name
         * @param data Pointer to the RGB image data
         * @param width Image width
         * @param height Image height
         */
        void Encode(const std::string& filename, uint8_t *data, uint32_t width, uint32_t height);

    };
}
