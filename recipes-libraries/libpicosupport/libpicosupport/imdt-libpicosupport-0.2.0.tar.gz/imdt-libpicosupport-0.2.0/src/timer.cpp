/**
 * @file timer.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "pico_support/timer.hpp"

using namespace pico_support;

/**
 *
 */
void Timer::Start()
{
    _start = std::chrono::system_clock::now();
}

/**
 *
 */
void Timer::Stop()
{
    _end = std::chrono::system_clock::now();
}

/**
 *
 */
std::chrono::duration<double> Timer::Elapsed() const
{
    return (_end - _start);
}
