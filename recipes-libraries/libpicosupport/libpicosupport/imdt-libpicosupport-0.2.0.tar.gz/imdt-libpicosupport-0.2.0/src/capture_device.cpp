/**
 * @file capture_device.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson
 */

#include "pico_support/capture_device.hpp"

#include <sys/ioctl.h>
#include <sys/mman.h>

#include <linux/videodev2.h>

#include <fcntl.h>

#include <cstring>
#include <cstdint>
#include <iostream>
#include <map>

using namespace pico_support;

struct PixelFormat
{
    uint32_t v4l2_pixel_format;
    bool enable_source_format_override;
};

static std::map<CaptureVideoFormat, PixelFormat> pixel_formats =
{
    { CaptureVideoFormat::RGB24, { V4L2_PIX_FMT_RGB24, true } },
    { CaptureVideoFormat::YUV422, { V4L2_PIX_FMT_YUYV, true } },
    { CaptureVideoFormat::BGR24, { V4L2_PIX_FMT_BGR24, true } },
    { CaptureVideoFormat::GRBG10, { V4L2_PIX_FMT_SGRBG10, false } },
    { CaptureVideoFormat::GRBG12, { V4L2_PIX_FMT_SGRBG12, false } },
    { CaptureVideoFormat::BGGR10, { V4L2_PIX_FMT_SBGGR10, false } },
};

std::map<CaptureDeviceError, std::string> CaptureDeviceException::_error_descriptions =
{
    { CaptureDeviceError::kFailedToOpenDevice, "Failed to open capture device" },
    { CaptureDeviceError::kFailedToQueryCapabilities, "Failed to query capabilities" },
    { CaptureDeviceError::kFailedToSetFormat, "Failed to set format" },
    { CaptureDeviceError::kFailedToSetFrameRate, "Failed to set frame rate" },
    { CaptureDeviceError::kFailedToRequestBuffers, "Failed to request buffers" },
    { CaptureDeviceError::kFailedToQueueBuffer, "Failed to queue buffer" },
    { CaptureDeviceError::kFailedToDequeueBuffer, "Failed to dequeue buffer" },
    { CaptureDeviceError::kFailedToReleaseBuffers, "Failed to release buffers" },

    { CaptureDeviceError::kFailedToStartStreaming, "Failed to start streaming" },
    { CaptureDeviceError::kFailedToStopStreaming, "Failed to stop streaming" },

    { CaptureDeviceError::kFailedToMapBuffer, "Failed to map buffer" },
    { CaptureDeviceError::kFailedToUnmapBuffer, "Failed to unmap buffer" },
};

/**
 *
 */
CaptureDevice::CaptureDevice()
{
}

/**
 *
 */
CaptureDevice::~CaptureDevice()
{
    // Delete the capture buffers; this unmaps the memory
    _buffers.clear();

    if (_fd >= 0)
    {
        // Release the V4L buffers
        ReleaseBuffers();
    }
}

/**
 * @todo Verify capabilities; this may be required when working with different sensors
 */
void CaptureDevice::Open(const std::string& device_name)
{
    _fd = ::open(device_name.c_str(), O_RDWR);

    if (_fd < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToOpenDevice);
    }

    // Query the capabilities

    struct v4l2_capability cap;
    memset(&cap, 0, sizeof(cap));

    int r = ioctl(_fd, VIDIOC_QUERYCAP, &cap);

    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToQueryCapabilities);
    }

    uint32_t capabilities { 0U };

    if (cap.capabilities & V4L2_CAP_DEVICE_CAPS)
    {
        capabilities = cap.device_caps;
    }
    else
    {
        capabilities = cap.capabilities;
    }

    _buffer_type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (capabilities & V4L2_CAP_VIDEO_CAPTURE_MPLANE)
    {
        _buffer_type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    }

    _memory_type = V4L2_MEMORY_MMAP;
}

/**
 * @note We override the source format in the ISI to suit the AP1302 ISP
 */
void CaptureDevice::SetFormat(const uint32_t width, const uint32_t height, const CaptureVideoFormat video_format)
{
    struct v4l2_format fmt;
    memset(&fmt, 0, sizeof(fmt));

    fmt.type = _buffer_type;
    fmt.fmt.pix_mp.width = width;
    fmt.fmt.pix_mp.height = height;

    if (pixel_formats.end() != pixel_formats.find(video_format))
    {
        auto pixel_format = pixel_formats.at(video_format);

        fmt.fmt.pix_mp.pixelformat = pixel_format.v4l2_pixel_format;

        if (pixel_format.enable_source_format_override)
        {
            system("echo 0x2011 > /sys/devices/platform/soc@0/32c00000.bus/32c00000.bus:camera/32e00000.isi/32e00000.isi:cap_device/source_format");
        }
        else
        {
            system("echo 0 > /sys/devices/platform/soc@0/32c00000.bus/32c00000.bus:camera/32e00000.isi/32e00000.isi:cap_device/source_format");
        }
    }

    fmt.fmt.pix_mp.field = V4L2_FIELD_NONE;
    fmt.fmt.pix_mp.num_planes = 1;
    fmt.fmt.pix_mp.plane_fmt[0].bytesperline = 0;

    int r = ioctl(_fd, VIDIOC_S_FMT, &fmt);
    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToSetFormat);
    }

    _width = width;
    _height = height;
}

/**
 * @note We swap the numerator and denominator to turn the user's requested frame rate
 * into the V4L2-compliant frame interval
 */
void CaptureDevice::SetFrameRate(const uint32_t numerator, const uint32_t denominator)
{
    // Set the frame rate

    struct v4l2_streamparm parm;
    memset(&parm, 0, sizeof(parm));

    parm.type = _buffer_type;
    parm.parm.capture.timeperframe.numerator = denominator;
    parm.parm.capture.timeperframe.denominator = numerator;

    int r = ioctl(_fd, VIDIOC_S_PARM, &parm);
    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToSetFrameRate);
    }
}

/**
 *
 */
void CaptureDevice::AllocateBuffers(const size_t number_of_buffers)
{
    struct v4l2_plane planes[1];
    struct v4l2_requestbuffers rb;
    struct v4l2_buffer buf;

    memset(&rb, 0, sizeof rb);
    rb.count = number_of_buffers;
    rb.type = _buffer_type;
    rb.memory = _memory_type;

    int r = ioctl(_fd, VIDIOC_REQBUFS, &rb);
    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToRequestBuffers);
    }

    _buffers.resize(rb.count);

    for (auto i = 0; i < _buffers.size(); i++)
    {
        _buffers[i] = std::make_shared<CaptureBuffer>();
    }

    // Map the buffers

    for (uint32_t i = 0; i < rb.count; ++i)
    {
        memset(&buf, 0, sizeof buf);
        memset(planes, 0, sizeof planes);

        buf.index = i;
        buf.type = _buffer_type;
        buf.memory = _memory_type;
        buf.length = 1;
        buf.m.planes = planes;

        r = ioctl(_fd, VIDIOC_QUERYBUF, &buf);
        if (r < 0)
        {
            throw CaptureDeviceException(CaptureDeviceError::kFailedToRequestBuffers);
        }

        _buffers[i]->SetIndex(i);
        _buffers[i]->MemoryMapBuffer(_fd, &buf);
    }

    // Queue the buffers

    for (uint32_t i = 0; i < number_of_buffers; i++)
    {
        struct v4l2_buffer buf;
        struct v4l2_plane planes[1];

        memset(&buf, 0, sizeof buf);
        memset(&planes, 0, sizeof planes);

        buf.index = i;
        buf.type = _buffer_type;
        buf.memory = _memory_type;
        buf.m.planes = planes;
        buf.length = 1;

        r = ioctl(_fd, VIDIOC_QBUF, &buf);
        if (r < 0)
        {
            throw CaptureDeviceException(CaptureDeviceError::kFailedToQueueBuffer);
        }
    }
}

/**
 *
 */
void CaptureDevice::StartStream()
{
    int type = _buffer_type;
    int ret;

    ret = ioctl(_fd, VIDIOC_STREAMON, &type);
    if (ret < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToStartStreaming);
    }
}

/**
 *
 */
void CaptureDevice::StopStream()
{
    int type = _buffer_type;
    int ret;

    ret = ioctl(_fd, VIDIOC_STREAMOFF, &type);
    if (ret < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToStopStreaming);
    }
}

/**
 *
 */
CaptureBufferSPtr CaptureDevice::WaitForNextImage()
{
    struct v4l2_plane planes[1];
    struct v4l2_buffer buf;

    memset(&buf, 0, sizeof buf);
    memset(planes, 0, sizeof planes);

    buf.type = _buffer_type;
    buf.memory = _memory_type;
    buf.length = 1;
    buf.m.planes = planes;

    int r = ioctl(_fd, VIDIOC_DQBUF, &buf);
    if (r < 0)
    {
        if (errno != EIO)
        {
            throw CaptureDeviceException(CaptureDeviceError::kFailedToDequeueBuffer);
        }
    }

    _buffers[buf.index]->SetTimestamp(buf.timestamp);

    return _buffers[buf.index];
}

/**
 *
 */
void CaptureDevice::RequeueBuffer(CaptureBufferSPtr buffer)
{
    struct v4l2_buffer buf;
    struct v4l2_plane planes[1];

    memset(&buf, 0, sizeof buf);
    memset(&planes, 0, sizeof planes);

    buf.index = buffer->GetIndex();
    buf.type = _buffer_type;
    buf.memory = _memory_type;
    buf.m.planes = planes;
    buf.length = 1;

    int r = ioctl(_fd, VIDIOC_QBUF, &buf);
    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToQueueBuffer);
    }
}

/*
 *
 *
 *
 */

/**
 *
 */
void CaptureDevice::ReleaseBuffers()
{
    struct v4l2_requestbuffers rb;
    memset(&rb, 0, sizeof rb);
    rb.count = 0;
    rb.type = _buffer_type;
    rb.memory = _memory_type;

    int ret = ioctl(_fd, VIDIOC_REQBUFS, &rb);
    if (ret < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToReleaseBuffers);
    }
}

/*
 *
 *
 *
 */

/**
 *
 */
CaptureBuffer::CaptureBuffer()
{
}

/**
 *
 */
CaptureBuffer::~CaptureBuffer()
{
    int r = munmap(_data, _size);
    if (r < 0)
    {
        /// @todo Don't throw in a destructor...
        throw CaptureDeviceException(CaptureDeviceError::kFailedToUnmapBuffer);
    }
}

/**
 *
 */
void CaptureBuffer::SetIndex(const uint32_t index)
{
    _index = index;
}

/**
 *
 */
void CaptureBuffer::MemoryMapBuffer(const int fd, v4l2_buffer *buf)
{
    uint32_t length = buf->length;
    uint32_t offset = buf->m.offset;

    if (V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE == buf->type)
    {
        length = buf->m.planes[0].length;
        offset = buf->m.planes[0].m.mem_offset;
    }

    _data = mmap(0, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, offset);

    if (_data == MAP_FAILED)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToMapBuffer);
    }

    _size = length;
}

/**
 *
 */
void CaptureBuffer::SetTimestamp(const timeval& monotonic_tv)
{
    // Convert the capture time to microseconds
    auto timestamp = std::chrono::seconds{monotonic_tv.tv_sec} + std::chrono::microseconds{monotonic_tv.tv_usec};
    auto timestamp_us = std::chrono::duration_cast<std::chrono::microseconds>(timestamp);

    // Record the current monotonic and real-time clocks
    auto monotonic_now = std::chrono::steady_clock::now();
    auto realtime_now = std::chrono::system_clock::now();

    // Calculate how long ago the image was captured, using the monotonic clock
    auto monotonic_now_us = std::chrono::duration_cast<std::chrono::microseconds>(monotonic_now.time_since_epoch());
    auto delta = monotonic_now_us - timestamp_us;

    // Convert the real-time clock to microseconds, and adjust using the delta
    auto realtime_now_us = std::chrono::duration_cast<std::chrono::microseconds>(realtime_now.time_since_epoch());
    realtime_now_us -= delta;

    // Store the result
    _timestamp.tv_sec = realtime_now_us.count() / 1000000;
    _timestamp.tv_usec = realtime_now_us.count() % 1000000;
}
