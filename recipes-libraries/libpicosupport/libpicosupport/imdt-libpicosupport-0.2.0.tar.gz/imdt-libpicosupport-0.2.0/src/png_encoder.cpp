/**
 * @file jpeg_encoder.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "pico_support/png_encoder.hpp"

#include <cstring>

using namespace pico_support;

/**
 *
 */
void PNGEncoder::Encode(const std::string& filename, uint8_t *data, uint32_t width, uint32_t height)
{
    png_image p;
    (void) memset(&p, 0, sizeof(p));

    p.version = PNG_IMAGE_VERSION;
    p.opaque = nullptr;
    p.format = PNG_FORMAT_RGB;
    p.width = width;
    p.height = height;

    png_image_write_to_file(&p, filename.c_str(), 0, data, 0, nullptr);

    png_image_free(&p);
}
