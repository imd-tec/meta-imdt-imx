/**
 * @file jpeg_encoder.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "pico_support/jpeg_encoder.hpp"

#include <fcntl.h>
#include <unistd.h>

using namespace pico_support;

/**
 *
 */
JPEGEncoder::JPEGEncoder()
{
    _instance = tjInitCompress();
}

/**
 *
 */
JPEGEncoder::~JPEGEncoder()
{
    tjDestroy(_instance);
}

/**
 *
 */
JPEGImage JPEGEncoder::Encode(uint8_t *data, uint32_t width, uint32_t height)
{
    uint8_t *buffer { nullptr };
    unsigned long output_size = 0;
    int output_subsampling = TJSAMP_422;
    int output_quality = 95;
    int flags = TJFLAG_FASTDCT;

    tjCompress2(_instance, data, width, 0, height, TJPF_RGB, &buffer, &output_size, output_subsampling, output_quality, flags);

    JPEGImage jpegImage;
    jpegImage.data = buffer;
    jpegImage.size = output_size;

    return jpegImage;
}

/**
 *
 */
void JPEGEncoder::Save(const std::string& filename, JPEGImage jpeg_image)
{
    uint8_t *data = jpeg_image.data;
    size_t size = jpeg_image.size;

    int fd = open(filename.c_str(), O_RDWR | O_CREAT | O_TRUNC | O_SYNC, 0644);

    while (size)
    {
        auto w = write(fd, data, size);
        data += w;
        size -= w;
    }

    close(fd);
}

/**
 *
 */
void JPEGEncoder::FreeBuffer(JPEGImage& jpeg_image)
{
    tjFree(jpeg_image.data);

    jpeg_image.data = nullptr;
    jpeg_image.size = 0;
}
