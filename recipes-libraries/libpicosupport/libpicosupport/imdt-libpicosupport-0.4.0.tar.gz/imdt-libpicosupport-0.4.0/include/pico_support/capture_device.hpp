/**
 * @file capture_device.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson
 */

#pragma once

#include "pico_support/ion_allocator.hpp"

#include <linux/videodev2.h>

#include <sys/time.h>

#include <cstdint>
#include <string>
#include <vector>
#include <memory>
#include <chrono>
#include <iostream>
#include <map>

namespace pico_support
{
    enum class CaptureVideoFormat
    {
        RGB24, YUV422, BGR24, GRBG10, GRBG12, BGGR10
    };

    class CaptureDevice;

    enum class CaptureDeviceError;

    using CaptureDeviceSPtr = std::shared_ptr<CaptureDevice>;

    /**
     * @brief Wrapper for a video capture device on the Pico board
     */
    class CaptureDevice
    {
    public:

        /**
         * @brief Constructor
         * @param ion_allocator ION buffer allocator
         */
        CaptureDevice(IonAllocatorSPtr ion_allocator);

        /**
         * @brief Releases and frees the buffers
         */
        ~CaptureDevice();

        /**
         * @brief Open the capture device
         * @param device_name Device name; defaults to the primary capture device on the Pico board
         */
        void Open(const std::string& device_name = "/dev/video3");

        /**
         * @brief Set the capture format
         * @param width Width in pixels
         * @param height Height in pixels
         * @param video_format Video format (enumerated)
         */
        void SetFormat(const uint32_t width,
                       const uint32_t height,
                       const CaptureVideoFormat video_format);

        /**
         * @brief Get the width
         * @return Width in pixels
         */
        uint32_t GetWidth();

        /**
         * @brief Get the height
         * @return Height in pixels
         */
        uint32_t GetHeight();

        /**
         * @brief Set the frame rate
         * @param numerator Frame rate, or numerator if value is fractional
         * @param denominator Optional denominator
         */
        void SetFrameRate(const uint32_t numerator, const uint32_t denominator = 1);

        /**
         * @brief Queue a series of pre-allocated buffers
         * @param number_of_buffers The number of buffers
         */
        void QueueBuffers(const size_t number_of_buffers);

        /**
         * @brief Start the video capture stream
         */
        void StartStream();

        /**
         * @brief Stop the video capture stream
         */
        void StopStream();

        /**
         * @brief Wait for the next available image from the capture device
         * @return Shared pointer to a CaptureBuffer object
         */
        IonCaptureBufferSPtr WaitForNextImage();

        /**
         * @brief Re-queue a capture buffer once it's no longer required
         * @param buffer Shared pointer to a CaptureBuffer object
         */
        void RequeueBuffer(IonCaptureBufferSPtr buffer);

    private:

        /**
         * @brief Release all the allocated buffers
         */
        void ReleaseBuffers();

        /// @brief Constant that indicates an invalid file descriptor
        static constexpr int InvalidFileDescriptor { -1 };

        /// @brief Capture device file descriptor
        int _fd { InvalidFileDescriptor };

        /// @brief V4L2 buffer type
        v4l2_buf_type _buffer_type { V4L2_BUF_TYPE_VIDEO_CAPTURE };

        /// @brief V4L2 memory type
        v4l2_memory _memory_type { V4L2_MEMORY_MMAP };

        /// @brief Vector of queued buffers; the buffers are owned by the ION allocator
        std::vector<IonCaptureBufferSPtr> _queued_buffers;

        /// @brief Capture width, in pixels
        uint32_t _width { 0 };

        /// @brief Capture height, in pixels
        uint32_t _height { 0 };

        /// @brief ION buffer allocator
        std::shared_ptr<IonAllocator> _ion_allocator;
    };

    inline
    uint32_t CaptureDevice::GetWidth()
    {
        return _width;
    }

    inline
    uint32_t CaptureDevice::GetHeight()
    {
        return _height;
    }

    /**
     * @brief Capture device exception
     */
    class CaptureDeviceException : public std::exception
    {
    public:

    	/**
    	 * @brief Constructor
    	 * @param c Error code
    	 */
        CaptureDeviceException(const CaptureDeviceError c);

        /**
         * @brief Access the error code
         * @return
         */
        CaptureDeviceError code() const;

        /**
         * @brief Access a description of the exception
         * @return
         */
        const char * what() const noexcept;

        /**
         * @brief Get the system error number that was logged at the time of the exception
         */
        int GetErrno();

    private:

        /// @brief Error code
        CaptureDeviceError _c;

        /// @brief System error code.
        int _errno {0};

        /// @brief A map from CaptureDeviceError to human readable string.
        static std::map<CaptureDeviceError, std::string> _error_descriptions;

    };

    inline
    CaptureDeviceException::CaptureDeviceException(const CaptureDeviceError c):
        _c(c),
        _errno(errno)
    {
    }

    inline
    CaptureDeviceError CaptureDeviceException::code() const
    {
        return _c;
    }

    inline
    int CaptureDeviceException::GetErrno()
    {
        return _errno;
    }

    enum class CaptureDeviceError
    {
        kFailedToOpenDevice,
        kFailedToQueryCapabilities,
        kFailedToSetFormat,
        kFailedToSetFrameRate,
        kFailedToRequestBuffers,
        kFailedToQueueBuffer,
        kFailedToDequeueBuffer,
        kFailedToReleaseBuffers,

        kFailedToStartStreaming,
        kFailedToStopStreaming,

        kInvalidNumberOfBuffers,
        kFailedToSetISISourceFormat,
    };
}
