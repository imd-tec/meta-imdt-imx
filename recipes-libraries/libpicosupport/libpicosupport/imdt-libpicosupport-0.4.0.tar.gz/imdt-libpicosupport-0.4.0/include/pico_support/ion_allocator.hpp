/**
 * @file ion_allocator.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson
 */

#pragma once

#include <memory>
#include <vector>
#include <cstdint>
#include <map>
#include <string>
#include <exception>

namespace pico_support
{
    class IonAllocator;

    using IonAllocatorSPtr = std::shared_ptr<IonAllocator>;

    class IonCaptureBuffer;

    using IonCaptureBufferSPtr = std::shared_ptr<IonCaptureBuffer>;

    enum class IonAllocatorError;

    /**
     * @brief ION buffer allocator
     * @details Provides access to the ION allocator, and manages a pool of buffers
     */
    class IonAllocator
    {
    public:

        /**
         * @brief Constructor
         * @details Opens the /dev/ion device and requests the heap ID mask
         */
        IonAllocator();

        /**
         * @brief Closes the device
         */
        ~IonAllocator();

        /**
         * @brief Creates a pool of buffers
         * @param number_of_buffers The number of buffers
         * @param buffer_size_bytes The size of each buffer in bytes
         */
        void CreateBufferPool(const size_t number_of_buffers,
                              const size_t buffer_size_bytes);

        /**
         * @brief Allocate an individual buffer
         * @param buffer_size_bytes The size of the buffer in bytes
         * @return File descriptor for the buffer
         */
        int Allocate(const size_t buffer_size_bytes);

        /**
         * @brief Get an unused buffer from the pool
         * @return Buffer shared pointer, or nullptr if the pool has been exhausted
         */
        IonCaptureBufferSPtr GetBufferFromPool();

        /**
         * @brief Return a queued buffer to the pool
         * @param buffer Buffer shared pointer
         *
         * @note This method has no effect if the buffer is locked
         */
        void ReturnBufferToPool(IonCaptureBufferSPtr buffer);

    private:

        /**
         * @brief Get the heap ID mask from the ION device
         */
        void GetHeapIdMask();

        static constexpr int kInvalidFd { -1 };

        /// @brief /dev/ion file descriptor
        int _fd { kInvalidFd };

        /// @brief Cached copy of the head ID mask
        uint32_t _heap_id_mask { 0 };

        /// @brief Pool of buffers
        std::vector<IonCaptureBufferSPtr> _buffers;

    };

    /*
     *
     *
     *
     */

    enum IonCaptureBufferState
    {
        Unused, Queued, Locked
    };

    /**
     * @brief ION capture buffer
     */
    class IonCaptureBuffer
    {
    public:

        /**
         * @brief Constructor
         * @param allocator ION allocator reference
         * @param buffer_size_bytes Buffer size in bytes
         * @param id Unique ID for the buffer (only used for debug purposes)
         */
        IonCaptureBuffer(IonAllocator& allocator,
                         const size_t buffer_size_bytes,
                         const size_t id);

        /**
         * @brief Destructor
         */
        ~IonCaptureBuffer();

        /**
         * @brief Mark the buffer as being queued in the capture driver
         */
        void MarkAsQueued();

        /**
         * @brief Lock the buffer
         * @details This prevents it from being re-queued in the capture driver
         */
        void Lock();

        /**
         * @brief Unlock the buffer
         */
        void Unlock();

        /**
         * @brief Mark the buffer as unused, e.g., when the capture driver has finished with it
         */
        void MarkAsUnused();

        /**
         * @brief Is the buffer unused?
         * @return Boolean
         */
        bool IsUnused() const;

        /**
         * @brief Is the buffer queued in the capture driver?
         * @return Boolean
         */
        bool IsQueued() const;

        /**
         * @brief Is the buffer locked?
         * @return Boolean
         */
        bool IsLocked() const;

        /**
         * @brief Set the V4L buffer index
         * @param index Buffer index
         */
        void SetIndex(const uint32_t index);

        /**
         * @brief Get the V4L buffer index
         * @return Buffer index
         */
        uint32_t GetIndex() const;

        /**
         * @brief Access the memory-mapped buffer
         * @return Data pointer
         */
        uint8_t *GetData() const;

        /**
         * @brief Get the size of the buffer
         * @return Size in bytes
         */
        size_t GetSize() const;

        /**
         * @brief Get the buffer ID (used for debug only)
         * @return Unique ID assigned on construction
         */
        size_t GetID() const;

        /**
         * @brief Set the timestamp
         * @param monotonic_ts steady_clock time at which the image was captured
         */
        void SetTimestamp(const timeval& monotonic_ts);

        /**
         * @brief Get the wall time timestamp at which the image was captured
         * @return Time in seconds and microseconds since the epoch
         */
        const timeval& GetTimestamp() const;

        /**
         * @brief Set the sensor index for this buffer
         * @param sensor_index Camera sensor index
         */
        void SetSensorIndex(const size_t sensor_index);

        /**
         * @brief Get the sensor index for this buffer
         * @return Camera sensor index
         */
        uint32_t GetSensorIndex() const;

        /**
         * @brief Synchronise the buffer before handing it to the user
         */
        void SyncForUser();

        /**
         * @brief Synchronise the buffer before handing it to the DMA controller
         */
        void SyncForDma();

    private:

        /**
         * @brief Update the buffer state
         * @param state The new state
         */
        void SetState(const IonCaptureBufferState state);

        static constexpr int kInvalidFd { -1 };

        /// @brief ION allocator reference
        IonAllocator& _allocator;

        /// @brief Buffer size in bytes
        size_t _buffer_size_bytes;

        /// @brief Buffer file descriptor
        int _fd { kInvalidFd };

        /// @brief Memory-mapped data pointer
        void *_data { nullptr };

        /// @brief Buffer state
        IonCaptureBufferState _state { IonCaptureBufferState::Unused };

        /// @brief Unique ID
        size_t _id;

        /// @brief V4L buffer index
        uint32_t _index { 0 };

        /// @brief Wall-clock timestamp
        timeval _timestamp;

        /// @brief Camera sensor index
        size_t _sensor_index { 0 };

    };

    inline
    void IonCaptureBuffer::MarkAsQueued()
    {
        SetState(IonCaptureBufferState::Queued);
    }

    inline
    void IonCaptureBuffer::Lock()
    {
        SetState(IonCaptureBufferState::Locked);
    }

    inline
    void IonCaptureBuffer::Unlock()
    {
        SetState(IonCaptureBufferState::Unused);
    }

    inline
    void IonCaptureBuffer::MarkAsUnused()
    {
        SetState(IonCaptureBufferState::Unused);
    }

    inline
    void IonCaptureBuffer::SetIndex(const uint32_t index)
    {
        _index = index;
    }

    inline
    void IonCaptureBuffer::SetState(const IonCaptureBufferState state)
    {
        _state = state;
    }

    inline
    bool IonCaptureBuffer::IsUnused() const
    {
        return (IonCaptureBufferState::Unused == _state);
    }

    inline
    bool IonCaptureBuffer::IsQueued() const
    {
        return (IonCaptureBufferState::Queued == _state);
    }

    inline
    bool IonCaptureBuffer::IsLocked() const
    {
        return (IonCaptureBufferState::Locked == _state);
    }

    inline
    uint32_t IonCaptureBuffer::GetIndex() const
    {
        return _index;
    }

    inline
    uint8_t *IonCaptureBuffer::GetData() const
    {
        return static_cast<uint8_t *>(_data);
    }

    inline
    size_t IonCaptureBuffer::GetSize() const
    {
        return _buffer_size_bytes;
    }

    inline
    size_t IonCaptureBuffer::GetID() const
    {
        return _id;
    }

    inline
    const timeval& IonCaptureBuffer::GetTimestamp() const
    {
        return _timestamp;
    }

    inline
    void IonCaptureBuffer::SetSensorIndex(const size_t sensor_index)
    {
        _sensor_index = sensor_index;
    }

    inline
    uint32_t IonCaptureBuffer::GetSensorIndex() const
    {
        return _sensor_index;
    }

    /**
     * @brief Ion allocator exception
     */
    class IonAllocatorException : public std::exception
    {
    public:

        /**
         * @brief Constructor
         * @param c Error code
         */
        IonAllocatorException(const IonAllocatorError c);

        /**
         * @brief Access the error code
         * @return
         */
        IonAllocatorError code() const;

        /**
         * @brief Access a description of the exception
         * @return
         */
        const char * what() const noexcept;

        /**
         * @brief Get the system error number that was logged at the time of the exception
         */
        int GetErrno();

    private:

        /// @brief Error code
        IonAllocatorError _c;

        /// @brief System error code.
        int _errno {0};

        /// @brief A map from IonAllocatorError to human readable string.
        static std::map<IonAllocatorError, std::string> _error_descriptions;

    };

    inline
    IonAllocatorException::IonAllocatorException(const IonAllocatorError c):
        _c(c),
        _errno(errno)
    {
    }

    inline
    IonAllocatorError IonAllocatorException::code() const
    {
        return _c;
    }

    inline
    int IonAllocatorException::GetErrno()
    {
        return _errno;
    }

    enum class IonAllocatorError
    {
        kFailedToOpenIonAllocator,
        kFailedToGetIonHeapMask,
        kBufferPoolAlreadyCreated,
        kFailedToAllocateIonBuffer,
        kFailedToMapBuffer,
        kFailedToSyncMemory,
    };
}
