/**
 * @file ion_allocator.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson
 */

#include "pico_support/ion_allocator.hpp"

#include <linux/ion.h>

#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/dma-buf.h>

#include <chrono>
#include <cstring>

using namespace pico_support;

std::map<IonAllocatorError, std::string> IonAllocatorException::_error_descriptions =
{
    { IonAllocatorError::kFailedToOpenIonAllocator, "Filed to open ION allocator"},
    { IonAllocatorError::kFailedToGetIonHeapMask, "Failed to get ION heap mask" },
    { IonAllocatorError::kBufferPoolAlreadyCreated, "Buffer pool has already been created" },
    { IonAllocatorError::kFailedToAllocateIonBuffer, "Failed to allocate ION buffer"},
    { IonAllocatorError::kFailedToMapBuffer, "Failed to map buffer" },
    { IonAllocatorError::kFailedToSyncMemory, "Failed sync memory buffer" },
};

/**
 *
 */
IonAllocator::IonAllocator()
{
    _fd = ::open("/dev/ion", O_RDONLY);

    if (_fd < 0)
    {
        throw IonAllocatorException(IonAllocatorError::kFailedToOpenIonAllocator);
    }

    GetHeapIdMask();
}

/**
 *
 */
IonAllocator::~IonAllocator()
{
    if (_fd >= 0)
    {
        ::close(_fd);
        _fd = kInvalidFd;
    }
}

/**
 *
 */
void IonAllocator::CreateBufferPool(const size_t number_of_buffers,
                                    const size_t buffer_size_bytes)
{
    if (_buffers.size() != 0)
    {
        throw IonAllocatorException(IonAllocatorError::kBufferPoolAlreadyCreated);
    }

    _buffers.resize(number_of_buffers);

    for (size_t i = 0; i < number_of_buffers; i++)
    {
        _buffers[i] = std::make_shared<IonCaptureBuffer>(*this, buffer_size_bytes, i);
    }
}

/**
 *
 */
int IonAllocator::Allocate(const size_t buffer_size_bytes)
{
    struct ion_allocation_data allocation_data = {};

    allocation_data.len = buffer_size_bytes;
    allocation_data.heap_id_mask = _heap_id_mask;
    allocation_data.flags = ION_FLAG_CACHED | ION_FLAG_NO_ZERO;

    if (ioctl(_fd, ION_IOC_ALLOC, &allocation_data) < 0)
    {
        throw IonAllocatorException(IonAllocatorError::kFailedToAllocateIonBuffer);
    }

    return allocation_data.fd;
}

/**
 *
 */
IonCaptureBufferSPtr IonAllocator::GetBufferFromPool()
{
   for (auto buffer : _buffers)
   {
       if (buffer->IsUnused())
       {
           buffer->MarkAsQueued();
           return buffer;
       }
   }

   return nullptr;
}

/**
 *
 */
void IonAllocator::ReturnBufferToPool(IonCaptureBufferSPtr buffer)
{
    if (false == buffer->IsLocked())
    {
        buffer->MarkAsUnused();
    }
}

/*
 *
 * IonAllocator private methods
 *
 */

/**
 *
 */
void IonAllocator::GetHeapIdMask()
{
    _heap_id_mask = 0;

    struct ion_heap_query heap_query;
    memset(&heap_query, 0, sizeof(heap_query));

    if ((ioctl(_fd, ION_IOC_HEAP_QUERY, &heap_query) < 0) || (heap_query.cnt == 0))
    {
        throw IonAllocatorException(IonAllocatorError::kFailedToGetIonHeapMask);
    }

    uint32_t heap_count = heap_query.cnt;

    std::vector<ion_heap_data> heap_data(heap_count);

    heap_query.heaps = static_cast<uint64_t>(reinterpret_cast<uintptr_t>(heap_data.data()));

    if (ioctl(_fd, ION_IOC_HEAP_QUERY, &heap_query) < 0)
    {
        throw IonAllocatorException(IonAllocatorError::kFailedToGetIonHeapMask);
    }

    for (size_t i = 0; i < heap_count; ++i)
    {
        if (heap_data[i].type == ION_HEAP_TYPE_DMA)
        {
            _heap_id_mask |= 1u << heap_data[i].heap_id;
        }
    }
}

/*
 *
 * IonCaptureBuffer public methods
 *
 */

/**
 *
 */
IonCaptureBuffer::IonCaptureBuffer(IonAllocator& allocator,
                                   const size_t buffer_size_bytes,
                                   const size_t id):
    _allocator(allocator),
    _buffer_size_bytes(buffer_size_bytes),
    _id(id)
{
    _fd = _allocator.Allocate(buffer_size_bytes);

    _data = mmap(0, _buffer_size_bytes, PROT_READ | PROT_WRITE, MAP_SHARED, _fd, 0);

    if (MAP_FAILED == _data)
    {
        throw IonAllocatorException(IonAllocatorError::kFailedToMapBuffer);
    }
}

/**
 *
 */
IonCaptureBuffer::~IonCaptureBuffer()
{
    close(_fd);
    munmap(_data, _buffer_size_bytes);
}

/**
 *
 */
void IonCaptureBuffer::SyncForUser()
{
    struct dma_buf_sync sync = {};

    sync.flags = DMA_BUF_SYNC_START | DMA_BUF_SYNC_READ;
    int ret = ioctl(_fd, DMA_BUF_IOCTL_SYNC, &sync);
    if (ret < 0)
    {
        throw IonAllocatorException(IonAllocatorError::kFailedToSyncMemory);
    }
}

/**
 *
 */
void IonCaptureBuffer::SyncForDma()
{
    struct dma_buf_sync sync = {};

    sync.flags = DMA_BUF_SYNC_END | DMA_BUF_SYNC_READ;
    int ret = ioctl(_fd, DMA_BUF_IOCTL_SYNC, &sync);
    if (ret < 0)
    {
        throw IonAllocatorException(IonAllocatorError::kFailedToSyncMemory);
    }
}

/**
 *
 */
void IonCaptureBuffer::SetTimestamp(const timeval& monotonic_tv)
{
    // Convert the capture time to microseconds
    auto timestamp = std::chrono::seconds{monotonic_tv.tv_sec} + std::chrono::microseconds{monotonic_tv.tv_usec};
    auto timestamp_us = std::chrono::duration_cast<std::chrono::microseconds>(timestamp);

    // Record the current monotonic and real-time clocks
    auto monotonic_now = std::chrono::steady_clock::now();
    auto realtime_now = std::chrono::system_clock::now();

    // Calculate how long ago the image was captured, using the monotonic clock
    auto monotonic_now_us = std::chrono::duration_cast<std::chrono::microseconds>(monotonic_now.time_since_epoch());
    auto delta = monotonic_now_us - timestamp_us;

    // Convert the real-time clock to microseconds, and adjust using the delta
    auto realtime_now_us = std::chrono::duration_cast<std::chrono::microseconds>(realtime_now.time_since_epoch());
    realtime_now_us -= delta;

    // Store the result
    _timestamp.tv_sec = realtime_now_us.count() / 1000000;
    _timestamp.tv_usec = realtime_now_us.count() % 1000000;
}

/*
 *
 * IonAllocatorException public methods
 *
 */

/**
 *
 */
const char * IonAllocatorException::what() const noexcept
{
    if (_error_descriptions.end() != _error_descriptions.find(_c))
    {
        return _error_descriptions[_c].c_str();
    }

    return "Unknown error";
}
