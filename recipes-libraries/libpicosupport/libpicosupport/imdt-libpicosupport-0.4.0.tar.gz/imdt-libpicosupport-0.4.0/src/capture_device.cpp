/**
 * @file capture_device.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson
 */

#include "pico_support/capture_device.hpp"

#include <sys/ioctl.h>
#include <linux/videodev2.h>

#include <fcntl.h>
#include <unistd.h>

#include <cstring>
#include <cstdint>
#include <iostream>
#include <map>
#include <sstream>

using namespace pico_support;

struct PixelFormat
{
    uint32_t v4l2_pixel_format;
    bool enable_source_format_override;
};

static std::map<CaptureVideoFormat, PixelFormat> pixel_formats =
{
    { CaptureVideoFormat::RGB24, { V4L2_PIX_FMT_RGB24, true } },
    { CaptureVideoFormat::YUV422, { V4L2_PIX_FMT_YUYV, true } },
    { CaptureVideoFormat::BGR24, { V4L2_PIX_FMT_BGR24, true } },
    { CaptureVideoFormat::GRBG10, { V4L2_PIX_FMT_SGRBG10, false } },
    { CaptureVideoFormat::GRBG12, { V4L2_PIX_FMT_SGRBG12, false } },
    { CaptureVideoFormat::BGGR10, { V4L2_PIX_FMT_SBGGR10, false } },
};

std::map<CaptureDeviceError, std::string> CaptureDeviceException::_error_descriptions =
{
    { CaptureDeviceError::kFailedToOpenDevice, "Failed to open capture device" },
    { CaptureDeviceError::kFailedToQueryCapabilities, "Failed to query capabilities" },
    { CaptureDeviceError::kFailedToSetFormat, "Failed to set format" },
    { CaptureDeviceError::kFailedToSetFrameRate, "Failed to set frame rate" },
    { CaptureDeviceError::kFailedToRequestBuffers, "Failed to request buffers" },
    { CaptureDeviceError::kFailedToQueueBuffer, "Failed to queue buffer" },
    { CaptureDeviceError::kFailedToDequeueBuffer, "Failed to dequeue buffer" },
    { CaptureDeviceError::kFailedToReleaseBuffers, "Failed to release buffers" },

    { CaptureDeviceError::kFailedToStartStreaming, "Failed to start streaming" },
    { CaptureDeviceError::kFailedToStopStreaming, "Failed to stop streaming" },

    { CaptureDeviceError::kInvalidNumberOfBuffers, "Invalid number of buffers; must be >= 2" },
    { CaptureDeviceError::kFailedToSetISISourceFormat, "Failed to set ISI source format" },
};

/*
 *
 * CaptureDevice public methods
 *
 */

/**
 *
 */
CaptureDevice::CaptureDevice(IonAllocatorSPtr ion_allocator):
    _ion_allocator(ion_allocator)
{
}

/**
 *
 */
CaptureDevice::~CaptureDevice()
{
    if (_fd >= 0)
    {
        // Release the V4L buffers
        ReleaseBuffers();
        ::close(_fd);
        _fd = InvalidFileDescriptor;
    }
}

/**
 * @todo Verify capabilities; this may be required when working with different sensors
 */
void CaptureDevice::Open(const std::string& device_name)
{
    _fd = ::open(device_name.c_str(), O_RDWR);

    if (_fd < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToOpenDevice);
    }

    // Query the capabilities

    struct v4l2_capability cap;
    memset(&cap, 0, sizeof(cap));

    int r = ioctl(_fd, VIDIOC_QUERYCAP, &cap);

    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToQueryCapabilities);
    }

    uint32_t capabilities { 0U };

    if (cap.capabilities & V4L2_CAP_DEVICE_CAPS)
    {
        capabilities = cap.device_caps;
    }
    else
    {
        capabilities = cap.capabilities;
    }

    _buffer_type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    if (capabilities & V4L2_CAP_VIDEO_CAPTURE_MPLANE)
    {
        _buffer_type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    }

    _memory_type = V4L2_MEMORY_USERPTR;
}

/**
 * @note We override the source format in the ISI to suit the AP1302 ISP
 */
void CaptureDevice::SetFormat(const uint32_t width, const uint32_t height, const CaptureVideoFormat video_format)
{
    struct v4l2_format fmt;
    memset(&fmt, 0, sizeof(fmt));

    fmt.type = _buffer_type;
    fmt.fmt.pix_mp.width = width;
    fmt.fmt.pix_mp.height = height;

    if (pixel_formats.end() != pixel_formats.find(video_format))
    {
        auto pixel_format = pixel_formats.at(video_format);

        fmt.fmt.pix_mp.pixelformat = pixel_format.v4l2_pixel_format;

        std::stringstream command;
        command << "echo ";
        command << (pixel_format.enable_source_format_override ? "0x2011" : "0");
        command << " > /sys/devices/platform/soc@0/32c00000.bus/32c00000.bus:camera/32e00000.isi/32e00000.isi:cap_device/source_format";

        int status = system(command.str().c_str());

        if (0 != status)
        {
            throw CaptureDeviceException(CaptureDeviceError::kFailedToSetISISourceFormat);
        }
    }

    fmt.fmt.pix_mp.field = V4L2_FIELD_NONE;
    fmt.fmt.pix_mp.num_planes = 1;
    fmt.fmt.pix_mp.plane_fmt[0].bytesperline = 0;

    int r = ioctl(_fd, VIDIOC_S_FMT, &fmt);
    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToSetFormat);
    }

    _width = width;
    _height = height;
}

/**
 * @note We swap the numerator and denominator to turn the user's requested frame rate
 * into the V4L2-compliant frame interval
 */
void CaptureDevice::SetFrameRate(const uint32_t numerator, const uint32_t denominator)
{
    // Set the frame rate

    struct v4l2_streamparm parm;
    memset(&parm, 0, sizeof(parm));

    parm.type = _buffer_type;
    parm.parm.capture.timeperframe.numerator = denominator;
    parm.parm.capture.timeperframe.denominator = numerator;

    int r = ioctl(_fd, VIDIOC_S_PARM, &parm);
    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToSetFrameRate);
    }
}

/**
 *
 */
void CaptureDevice::QueueBuffers(const size_t number_of_buffers)
{
    struct v4l2_plane planes[1];
    struct v4l2_requestbuffers rb;
    struct v4l2_buffer buf;

    if (number_of_buffers < 2)
    {
        throw CaptureDeviceException(CaptureDeviceError::kInvalidNumberOfBuffers);
    }

    memset(&rb, 0, sizeof rb);
    rb.count = number_of_buffers;
    rb.type = _buffer_type;
    rb.memory = _memory_type;

    int r = ioctl(_fd, VIDIOC_REQBUFS, &rb);
    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToRequestBuffers);
    }

    // Queue the buffers

    for (uint32_t index = 0; index < rb.count; index++)
    {
        auto buffer = _ion_allocator->GetBufferFromPool();

        _queued_buffers.push_back(buffer);

        memset(&buf, 0, sizeof buf);
        memset(planes, 0, sizeof planes);

        buf.index = index;
        buf.type = _buffer_type;
        buf.memory = _memory_type;
        buf.length = 1;
        buf.m.planes = planes;

        buffer->SetIndex(index);

        planes[0].length = static_cast<uint32_t>(buffer->GetSize());
        planes[0].m.userptr = (unsigned long)buffer->GetData();

        r = ioctl(_fd, VIDIOC_QBUF, &buf);
        if (r < 0)
        {
            throw CaptureDeviceException(CaptureDeviceError::kFailedToQueueBuffer);
        }
    }
}

/**
 *
 */
void CaptureDevice::StartStream()
{
    int type = _buffer_type;
    int ret;

    ret = ioctl(_fd, VIDIOC_STREAMON, &type);
    if (ret < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToStartStreaming);
    }
}

/**
 *
 */
void CaptureDevice::StopStream()
{
    int type = _buffer_type;
    int ret;

    ret = ioctl(_fd, VIDIOC_STREAMOFF, &type);
    if (ret < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToStopStreaming);
    }
}

/**
 *
 */
IonCaptureBufferSPtr CaptureDevice::WaitForNextImage()
{
    struct v4l2_plane planes[1];
    struct v4l2_buffer buf;

    memset(&buf, 0, sizeof buf);
    memset(planes, 0, sizeof planes);

    buf.type = _buffer_type;
    buf.memory = _memory_type;
    buf.length = 1;
    buf.m.planes = planes;

    int r = ioctl(_fd, VIDIOC_DQBUF, &buf);
    if (r < 0)
    {
        if (errno != EIO)
        {
            throw CaptureDeviceException(CaptureDeviceError::kFailedToDequeueBuffer);
        }
    }

    auto buffer = _queued_buffers[buf.index];

    buffer->SetTimestamp(buf.timestamp);
    buffer->SyncForUser();

    return buffer;
}

/**
 *
 */
void CaptureDevice::RequeueBuffer(IonCaptureBufferSPtr buffer)
{
    struct v4l2_buffer buf;
    struct v4l2_plane planes[1];

    memset(&buf, 0, sizeof buf);
    memset(&planes, 0, sizeof planes);

    buf.index = buffer->GetIndex();
    buf.type = _buffer_type;
    buf.memory = _memory_type;
    buf.m.planes = planes;
    buf.length = 1;

    planes[0].length = buffer->GetSize();
    planes[0].m.userptr = (unsigned long)buffer->GetData();
    
    buffer->SyncForDma();

    int r = ioctl(_fd, VIDIOC_QBUF, &buf);
    if (r < 0)
    {
        throw CaptureDeviceException(CaptureDeviceError::kFailedToQueueBuffer);
    }
}

/*
 *
 * CaptureDevice private methods
 *
 */

/**
 *
 */
void CaptureDevice::ReleaseBuffers()
{
    struct v4l2_requestbuffers rb;
    memset(&rb, 0, sizeof rb);
    rb.count = 0;
    rb.type = _buffer_type;
    rb.memory = _memory_type;

    int ret = ioctl(_fd, VIDIOC_REQBUFS, &rb);
    if (ret < 0)
    {
        /// @todo Report/log error (CaptureDeviceError::kFailedToReleaseBuffers)
    }

    for (auto buffer : _queued_buffers)
    {
        _ion_allocator->ReturnBufferToPool(buffer);
    }
}

/*
 *
 * CaptureDeviceException public methods
 *
 */

/**
 *
 */
const char * CaptureDeviceException::what() const noexcept
{
    if (_error_descriptions.end() != _error_descriptions.find(_c))
    {
        return _error_descriptions[_c].c_str();
    }

    return "Unknown error";
}
