/**
 * @file h264_encoder.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Lewis Purvis <lewisp@imd-tec.com>
 */

#include "pico_support/h264_encoder.hpp"
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <linux/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <map>

[[maybe_unused]]
static void PrintEncEncParams(VpuEncEncParam& p_enc_enc);

using namespace pico_support;

#define PAGE_ALIGN(x) (((x) + 4095) & ~4095)

std::map<H264EncoderError, std::string> H264EncoderException::_error_descriptions =
{
    {H264EncoderError::kInvalidCallWhenEncOpen, "Encoder is open. This function must be called when the encoder is closed."},
    {H264EncoderError::kInvalidCallWhenEncClosed, "Encoder is closed. This function must be called when the encoder is closed."},
    {H264EncoderError::kFailedToLoadVpuEncoder, "Failed to load the VPU encoder"},
    {H264EncoderError::kFailedToGetVpuVerInfo, "Failed to read VPU version information"},
    {H264EncoderError::kFailedToGetVpuWrapperVerInfo, "Failed to read VPU Wrapper version information"},
    {H264EncoderError::kFailedToQueryVpuMem, "Failed to read VPU memory requirements"},
    {H264EncoderError::kFailedToAllocVpuVirtMem, "Failed to allocate the VPU's requested working virtual memory"},
    {H264EncoderError::kFailedToAllocVpuPhysMem, "Failed to allocate the VPU's requested working physical memory"},
    {H264EncoderError::kEncOpenInvalidInputArgs, "Invalid encoder input arguments. Please ensure that they are within the bounds of the min/max values specified by this class."},
    {H264EncoderError::kFailedToOpenVpuEncoder, "Failed to open VPU encoder"},
    {H264EncoderError::kFailedToConfigureVpu, "Failed to configure VPU encoder"},
    {H264EncoderError::kFailedToAllocInputPhysBuffer, "Failed to allocate input buffer"},
    {H264EncoderError::kInputFrameResolutionMismatch, "Input frame resolution does not match encoder's configured resolution"},
    {H264EncoderError::kInputFrameFormatMismatch, "Input frame format does not match encoder's configured input frame format"},
    {H264EncoderError::kEncFrameInvalidInputArgs, "Invalid encode frame input arguments"},
    {H264EncoderError::kFailedToEncodeFrame, "Failed to encode input frame"},
    {H264EncoderError::kFailedToCloseVpu, "Failed to close VPU"},
    {H264EncoderError::kFailedToUnloadEncoder, "Failed to Unload the Encoder"},
    {H264EncoderError::kFailedToFreeEncInputPhysMem, "Failed to free encoder input physical memory"},
    {H264EncoderError::kFailedToFreeEncWorkingPhysMem, "Failed tof free encoder working physical memory"}
};

H264Encoder::H264Encoder()
{
    // initialise members to default
    ResetMembersToDefault();
    Initialise();
}

void H264Encoder::VpuQueryAllocMem()
{
    memset(&_vpu_working_mem_info, 0, sizeof(VpuMemInfo));
    VpuEncRetCode ret = VPU_EncQueryMem(&_vpu_working_mem_info);

    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToQueryVpuMem);
    }

    for (int i = 0; i < _vpu_working_mem_info.nSubBlockNum; i++)
    {
        size_t size = _vpu_working_mem_info.MemSubBlock[i].nAlignment + _vpu_working_mem_info.MemSubBlock[i].nSize;

        if (_vpu_working_mem_info.MemSubBlock[i].MemType == VPU_MEM_VIRT)
        {
            _vpu_working_mem_virt.resize(size);
            uint8_t *ptr = _vpu_working_mem_virt.data();
            void *retPtr = std::align(_vpu_working_mem_info.MemSubBlock[i].nAlignment, _vpu_working_mem_info.MemSubBlock[i].nSize, (void *&)ptr, size);
            if (!retPtr)
            {
                throw H264EncoderException(H264EncoderError::kFailedToAllocVpuVirtMem);
            }

            _vpu_working_mem_info.MemSubBlock[i].pVirtAddr = ptr;
        }
        else
        {
            memset(&_vpu_working_mem_desc, 0, sizeof(VpuMemDesc));

            // physical memory must be page aligned
            _vpu_working_mem_desc.nSize = static_cast<int>(PAGE_ALIGN(size));

            auto ret = VPU_EncGetMem(&_vpu_working_mem_desc);

            if (ret == VPU_ENC_RET_SUCCESS)
            {
                _vpu_working_mem_info.MemSubBlock[i].pPhyAddr = reinterpret_cast<uint8_t *>(_vpu_working_mem_desc.nPhyAddr);
                _vpu_working_mem_info.MemSubBlock[i].pVirtAddr = reinterpret_cast<uint8_t *>(_vpu_working_mem_desc.nVirtAddr);
            }
            else
            {
                throw H264EncoderException(H264EncoderError::kFailedToAllocVpuPhysMem);
            }
        }
    }
}

void H264Encoder::ResetMembersToDefault()
{
    memset(&_vpu_version_info, 0, sizeof(VpuVersionInfo));
    memset(&_vpu_wrapper_info, 0, sizeof(VpuWrapperVersionInfo));
    memset(&_vpu_enc_handle, 0, sizeof(VpuEncHandle));
    memset(&_vpu_input_frame_buffer, 0, sizeof(VpuFrameBuffer));
    memset(&_vpu_enc_params, 0, sizeof(VpuEncOpenParamSimp));

    _vpu_enc_params.eFormat = VPU_V_AVC;

    _vpu_enc_params.sMirror = VPU_ENC_MIRDIR_NONE;
    _vpu_enc_params.nBitRate = kDefaultBitrate;
    _vpu_enc_params.sColorAspects.nFullRange = 1;
    _vpu_enc_params.sColorAspects.nVideoSignalPresentFlag = 1;
    _vpu_enc_params.nColorConversionType = 1;
    _vpu_enc_params.nStreamSliceCount = 1;
    _vpu_enc_params.nIntraQP = kDefaultH264Quant;
    _vpu_enc_params.nChromaInterleave = 0;
    _vpu_enc_params.nMapType = 0;
    _vpu_enc_params.nLinear2TiledEnable = 0;
}

void H264Encoder::Initialise(void)
{
    if (_is_vpu_enc_open == true)
    {
        throw H264EncoderException(H264EncoderError::kInvalidCallWhenEncOpen);
    }

    VpuEncRetCode ret = VPU_EncLoad();
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToLoadVpuEncoder);
    }

    ret = VPU_EncGetVersionInfo(&_vpu_version_info);
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToGetVpuVerInfo);
    }

    ret = VPU_EncGetWrapperVersionInfo(&_vpu_wrapper_info);
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToGetVpuWrapperVerInfo);
    }

    VpuQueryAllocMem();
}

void H264Encoder::Open(const uint32_t width,
                       const uint32_t height,
                       const uint32_t frame_rate,
                       const EncoderInputVideoFormat input_format)
{

    if (_is_vpu_enc_open == true)
    {
        throw H264EncoderException(H264EncoderError::kInvalidCallWhenEncOpen);
    }

    _frame_input_format = input_format;

    // check input params
    if (width > kMaxInputWidth ||
        height > kMaxInputHeight ||
        frame_rate > kMaxFrameRate)
    {
        throw H264EncoderException(H264EncoderError::kEncOpenInvalidInputArgs);
    }

    _gop_size = kDefaultGopSize;
    _gop_count = 0;
    _total_frames = 0;

    _vpu_enc_params.nGOPSize = _gop_size;
    _vpu_enc_params.nPicWidth = width;
    _vpu_enc_params.nPicHeight = height;
    _vpu_enc_params.nFrameRate = frame_rate;

    // as we have the size of the input frame, we can now allocate memory for it
    // The VPU requires the memory to be physical memory, and aligned to a page boundary
    uint32_t buff_size;
    if (_frame_input_format == EncoderInputVideoFormat::RGBA)
    {
        buff_size = (width * height * 4);
        _vpu_enc_params.eColorFormat = VPU_COLOR_ARGB8888;// The vpu has no RGBA option. Gstreamer interprets RGBA as ARGB, and all seems to work as expected
    }
    else if (_frame_input_format == EncoderInputVideoFormat::YUV422)
    {
        buff_size = (width * height)*2;
        _vpu_enc_params.eColorFormat = VPU_COLOR_422YUYV;
        _vpu_enc_params.nChromaInterleave = 1;
    }
    else
    {
        throw H264EncoderException(H264EncoderError::kEncOpenInvalidInputArgs);
    }

    VpuEncRetCode ret = VPU_EncOpenSimp(&_vpu_enc_handle, &_vpu_working_mem_info, &_vpu_enc_params);
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToOpenVpuEncoder);
    }

    // configure the VPU encoder with default params
    ret = VPU_EncConfig(_vpu_enc_handle, VPU_ENC_CONF_NONE, nullptr);
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToConfigureVpu);
    }

    memset(&_vpu_input_mem_desc, 0, sizeof(VpuMemDesc));
    
    _vpu_input_mem_desc.nSize = static_cast<int>(PAGE_ALIGN(buff_size));
    
    ret = VPU_EncGetMem(&_vpu_input_mem_desc);
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToAllocInputPhysBuffer);
    }

    memset(reinterpret_cast<uint8_t *>(_vpu_input_mem_desc.nVirtAddr), 0, _vpu_input_mem_desc.nSize);

    _is_vpu_enc_open = true;
}

/**
 * @todo Log warning for if (!(enc_enc_param.eOutRetCode & VPU_ENC_INPUT_USED))
 */
uint32_t H264Encoder::EncodeFrame(const cv::Mat& frame, uint8_t *out_buff, uint32_t out_buff_max_size, bool force_idr)
{
    if (_is_vpu_enc_open == false)
    {
        throw H264EncoderException(H264EncoderError::kInvalidCallWhenEncClosed);
    }
   
    // check the input type matches the input frame type
    if (frame.rows != _vpu_enc_params.nPicHeight || frame.cols != _vpu_enc_params.nPicWidth)
    {
        throw H264EncoderException(H264EncoderError::kInputFrameResolutionMismatch);
    }

    uint32_t plane_offsets[3] = {0, 0, 0};
    uint32_t plane_stride_y = 0;
    uint32_t plane_stride_c = 0;
    
    if (_frame_input_format == EncoderInputVideoFormat::RGBA)
    {
        if (frame.channels() != 4)
        {
            throw H264EncoderException(H264EncoderError::kInputFrameFormatMismatch);
        }
        plane_stride_y = _vpu_enc_params.nPicWidth * 4;
        plane_stride_c = 0;

    }
    else if (_frame_input_format == EncoderInputVideoFormat::YUV422)
    {
        if (frame.channels() != 2)
        {
            throw H264EncoderException(H264EncoderError::kInputFrameFormatMismatch);
        }

        plane_stride_y = _vpu_enc_params.nPicWidth * 2;
        plane_stride_c = 0;
    }
    else
    {
        throw H264EncoderException(H264EncoderError::kInputFrameFormatMismatch);
    }

    // check input args
    uint32_t frame_buff_size = frame.total() * frame.elemSize();
    if (frame_buff_size > out_buff_max_size ||
        out_buff == nullptr)
    {
        throw H264EncoderException(H264EncoderError::kEncFrameInvalidInputArgs);
    }

    // copy our frame to our allocated memory
    memcpy(reinterpret_cast<uint8_t *>(_vpu_input_mem_desc.nVirtAddr), frame.data, frame_buff_size);

    // populate the input frame buffer object
    uint8_t *phys_ptr = reinterpret_cast<uint8_t *>(_vpu_input_mem_desc.nPhyAddr);
    _vpu_input_frame_buffer.pbufY = phys_ptr + plane_offsets[0];
    _vpu_input_frame_buffer.pbufCb = phys_ptr + plane_offsets[1];
    _vpu_input_frame_buffer.pbufCr = phys_ptr + plane_offsets[2];
    _vpu_input_frame_buffer.pbufMvCol = NULL; /* not used by the VPU encoder */
    _vpu_input_frame_buffer.nStrideY = plane_stride_y;
    _vpu_input_frame_buffer.nStrideC = plane_stride_c;

    // populate the encoder params object
    VpuEncEncParam enc_enc_param;
    memset(&enc_enc_param, 0, sizeof(VpuEncEncParam));

    enc_enc_param.nInVirtOutput = reinterpret_cast<unsigned long>(out_buff);
    enc_enc_param.nInOutputBufLen = frame_buff_size;
    enc_enc_param.nPicWidth = _vpu_enc_params.nPicWidth;
    enc_enc_param.nPicHeight = _vpu_enc_params.nPicHeight;
    enc_enc_param.nFrameRate = _vpu_enc_params.nFrameRate;
    enc_enc_param.pInFrame = &_vpu_input_frame_buffer;
    enc_enc_param.eFormat = _vpu_enc_params.eFormat;
    enc_enc_param.nQuantParam = kDefaultH264Quant;
    enc_enc_param.nForceIPicture = 0;


    uint32_t output_buffer_offset = 0;

    // Should this frame be and IFrame?
    if (((_gop_size && !(_gop_count % _gop_size)) || _gop_count == 0) ||
        force_idr)
    {
        enc_enc_param.nForceIPicture = 1;
        _gop_count = 0;
    }

    do
    {
        VpuEncRetCode ret = VPU_EncEncodeFrame(_vpu_enc_handle, &enc_enc_param);
        if (ret != VPU_ENC_RET_SUCCESS)
        {
            VPU_EncReset(_vpu_enc_handle);
            throw H264EncoderException(H264EncoderError::kFailedToEncodeFrame);
        }

        if (enc_enc_param.eOutRetCode & VPU_ENC_OUTPUT_SEQHEADER)
        {
            output_buffer_offset += enc_enc_param.nOutOutputSize;
            enc_enc_param.nInVirtOutput = reinterpret_cast<unsigned long>(out_buff) + output_buffer_offset;
            enc_enc_param.nInOutputBufLen = frame_buff_size - output_buffer_offset;
            continue;
        }

        if (enc_enc_param.eOutRetCode & VPU_ENC_OUTPUT_DIS)
        {
            _gop_count++;
            _total_frames++;
            output_buffer_offset += enc_enc_param.nOutOutputSize;
            // if (!(enc_enc_param.eOutRetCode & VPU_ENC_INPUT_USED))
            // {
            //     printf("frame finished, but VPU did not report the input as used"); // TODO
            // }

            break;
        }

    } while (!(enc_enc_param.eOutRetCode & VPU_ENC_INPUT_USED));

    return output_buffer_offset;
}

void H264Encoder::Close()
{
    // if (_is_vpu_enc_open == false)
    // {
    //     throw H264EncoderException(H264EncoderError::kInvalidCallWhenEncClosed);
    // }

    VpuEncRetCode ret = VPU_EncClose(_vpu_enc_handle);
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToCloseVpu);
    }

    ret = VPU_EncFreeMem(&_vpu_input_mem_desc);
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToFreeEncInputPhysMem);
    }

    _is_vpu_enc_open = false;
}

void H264Encoder::DeInitialise()
{
    VpuEncRetCode ret = VPU_EncUnLoad();
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToUnloadEncoder);
    }

    ret = VPU_EncFreeMem(&_vpu_working_mem_desc);
    if (ret != VPU_ENC_RET_SUCCESS)
    {
        throw H264EncoderException(H264EncoderError::kFailedToFreeEncWorkingPhysMem);
    }
}

void PrintEncEncParams(VpuEncEncParam& p_enc_enc)
{
    printf("eFormat: %u\r\n", p_enc_enc.eFormat);

    printf("nPicWidth: %i\r\n", p_enc_enc.nPicWidth);
    printf("nPicHeight: %i\r\n", p_enc_enc.nPicHeight);
    printf("nFrameRate: %i\r\n", p_enc_enc.nFrameRate);
    printf("nQuantParam: %i\r\n", p_enc_enc.nQuantParam);

    printf("nInPhyInput: %lx\r\n", p_enc_enc.nInPhyInput);
    printf("nInVirtInput: %lx\r\n", p_enc_enc.nInVirtInput);

    printf("nInInputSize: %i\r\n", p_enc_enc.nInInputSize);
    printf("nInPhyOutput: %lx\r\n", p_enc_enc.nInPhyOutput);
    printf("nInVirtOutput: %lx\r\n", p_enc_enc.nInVirtOutput);
    printf("nInOutputBufLen: %u\r\n", p_enc_enc.nInOutputBufLen);

    printf("nForceIPicture: %i\r\n", p_enc_enc.nForceIPicture);
    printf("nSkipPicture: %i\r\n", p_enc_enc.nSkipPicture);
    printf("nEnableAutoSkip: %i\r\n", p_enc_enc.nEnableAutoSkip);
}

H264Encoder::~H264Encoder()
{
    if (_is_vpu_enc_open)
    {
        Close();
    }
    
    DeInitialise();
}
