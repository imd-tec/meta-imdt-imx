/**
 * @file capture_device.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson
 */

#pragma once

#include <linux/videodev2.h>

#include <sys/time.h>

#include <cstdint>
#include <string>
#include <vector>
#include <memory>
#include <chrono>
#include <iostream>
#include <map>

namespace pico_support
{
    enum class CaptureVideoFormat
    {
        RGB24, YUV422, BGR24, GRBG10, GRBG12, BGGR10
    };

    class CaptureBuffer;
    class CaptureDevice;
    enum class CaptureDeviceError;

    using CaptureDeviceSPtr = std::shared_ptr<CaptureDevice>;
    using CaptureBufferSPtr = std::shared_ptr<CaptureBuffer>;

    /**
     * @brief Wrapper for a video capture device on the Pico board
     */
    class CaptureDevice
    {
    public:

        /**
         * @brief Default constructor
         */
        CaptureDevice();

        /**
         * @brief Releases and frees the buffers
         */
        ~CaptureDevice();

        /**
         * @brief Open the capture device
         * @param device_name Device name; defaults to the primary capture device on the Pico board
         */
        void Open(const std::string& device_name = "/dev/video3");

        /**
         * @brief Set the capture format
         * @param width Width in pixels
         * @param height Height in pixels
         * @param video_format Video format (enumerated)
         */
        void SetFormat(const uint32_t width,
                       const uint32_t height,
                       const CaptureVideoFormat video_format);

        /**
         * @brief Get the width
         * @return Width in pixels
         */
        uint32_t GetWidth();

        /**
         * @brief Get the height
         * @return Height in pixels
         */
        uint32_t GetHeight();

        /**
         * @brief Set the frame rate
         * @param numerator Frame rate, or numerator if value is fractional
         * @param denominator Optional denominator
         */
        void SetFrameRate(const uint32_t numerator, const uint32_t denominator = 1);

        /**
         * @brief Allocate a series of V4L2 buffers
         * @param number_of_buffers The number of buffers
         */
        void AllocateBuffers(const size_t number_of_buffers);

        /**
         * @brief Start the video capture stream
         */
        void StartStream();

        /**
         * @brief Stop the video capture stream
         */
        void StopStream();

        /**
         * @brief Wait for the next available image from the capture device
         * @return Shared pointer to a CaptureBuffer object
         */
        CaptureBufferSPtr WaitForNextImage();

        /**
         * @brief Requeue a capture buffer once it's no longer required
         * @param buffer Shared pointer to a CaptureBuffer object
         */
        void RequeueBuffer(CaptureBufferSPtr buffer);

    private:

        /**
         * @brief Release all the allocated buffers
         */
        void ReleaseBuffers();

        /// @brief Constant that indicates an invalid file descriptor
        static constexpr int InvalidFileDescriptor { -1 };

        /// @brief Capture device file descriptor
        int _fd { InvalidFileDescriptor };

        /// @brief V4L2 buffer type
        v4l2_buf_type _buffer_type { V4L2_BUF_TYPE_VIDEO_CAPTURE };

        /// @brief V4L2 memory type
        v4l2_memory _memory_type { V4L2_MEMORY_MMAP };

        /// @brief Vector of capture buffer objects
        std::vector<CaptureBufferSPtr> _buffers;

        /// @brief Capture width, in pixels
        uint32_t _width { 0 };

        /// @brief Capture height, in pixels
        uint32_t _height { 0 };
    };

    inline
    uint32_t CaptureDevice::GetWidth()
    {
        return _width;
    }

    inline
    uint32_t CaptureDevice::GetHeight()
    {
        return _height;
    }

    /**
     * @brief Encapsulates a V4L2 memory-mapped capture buffer
     */
    class CaptureBuffer
    {
    public:

        /**
         * @brief Default constructor
         */
        CaptureBuffer();

        /**
         * @brief Unmaps the buffer
         */
        ~CaptureBuffer();

        /**
         * @brief Set the index; this must align with the V4L2 index
         * @param index The index
         */
        void SetIndex(const uint32_t index);

        /**
         * @brief Get the index
         * @return The underlying V4L2 buffer index
         */
        uint32_t GetIndex() const;

        /**
         * @brief Map a V4L2 buffer into userspace memory
         * @param fd Capture device file descriptor
         * @param buf Pointer to a V4L2 buffer
         */
        void MemoryMapBuffer(const int fd, v4l2_buffer *buf);

        /**
         * @brief Access the memory-mapped location
         * @return
         */
        uint8_t *GetData() const;

        /**
         * @brief Return the size of the buffer
         * @return Size in bytes
         */
        size_t GetSize() const;

        /**
         * @brief Set the timestamp
         * @param monotonic_ts Monotonic clock timestamp
         *
         * @details The timestamp is converted to wall-clock time before it's stored
         */
        void SetTimestamp(const timeval& monotonic_ts);

        /**
         * @brief Get the wall-clock timestamp for this image
         * @return Wall-clock timestamp
         */
        const timeval& GetTimestamp() const;

    private:

        /// @brief V4L buffer index
        uint32_t _index { 0 };

        /// @brief Buffer size in bytes
        uint32_t _size { 0 };

        /// @brief Pointer to the memory-mapped buffer
        void *_data { nullptr };

        /// @brief Wall-clock timestamp
        timeval _timestamp;
    };

    inline
    const timeval& CaptureBuffer::GetTimestamp() const
    {
        return _timestamp;
    }

    inline
    uint32_t CaptureBuffer::GetIndex() const
    {
        return _index;
    }

    inline
    uint8_t *CaptureBuffer::GetData() const
    {
        return static_cast<uint8_t *>(_data);
    }

    inline
    size_t CaptureBuffer::GetSize() const
    {
        return _size;
    }

    /**
     * @brief Capture device exception
     */
    class CaptureDeviceException : public std::exception
    {
    public:

    	/**
    	 * @brief Constructor
    	 * @param c Error code
    	 */
        CaptureDeviceException(const CaptureDeviceError c);

        /**
         * @brief Access the error code
         * @return
         */
        CaptureDeviceError code() const;

        /**
         * @brief Access a description of the exception
         * @return
         */
        const char * what() const noexcept
        {
            if (_error_descriptions.end() != _error_descriptions.find(_c))
            {
                return _error_descriptions[_c].c_str();
            }

            return "Unknown error";
        }

    private:

        /// @brief Error code
        CaptureDeviceError _c;

        static std::map<CaptureDeviceError, std::string> _error_descriptions;

    };

    inline
    CaptureDeviceException::CaptureDeviceException(const CaptureDeviceError c):
        _c(c)
    {
    }

    inline
    CaptureDeviceError CaptureDeviceException::code() const
    {
        return _c;
    }

    enum class CaptureDeviceError
    {
        kFailedToOpenDevice,
        kFailedToQueryCapabilities,
        kFailedToSetFormat,
        kFailedToSetFrameRate,
        kFailedToRequestBuffers,
        kFailedToQueueBuffer,
        kFailedToDequeueBuffer,
        kFailedToReleaseBuffers,

        kFailedToStartStreaming,
        kFailedToStopStreaming,

        kFailedToMapBuffer,
        kFailedToUnmapBuffer,

        kInvalidNumberOfBuffers,
        kFailedToSetISISourceFormat,
    };
}
