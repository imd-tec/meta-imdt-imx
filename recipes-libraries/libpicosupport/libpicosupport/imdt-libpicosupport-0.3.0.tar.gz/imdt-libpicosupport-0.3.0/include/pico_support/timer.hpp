/**
 * @file timer.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include <chrono>

namespace pico_support
{
    /**
     * @brief A simple stopwatch, which uses the steady_clock to measure elapsed time
     */
    class Timer
    {
    public:

        /**
         * @brief Starts the timer
         */
        void Start();

        /**
         * @brief Stops the timer
         */
        void Stop();

        /**
         * @brief Returns the start time
         * @return std::chrono::steady_clock::time_point object
         */
        auto GetStart();

        /**
         * @brief Returns the end time
         * @return std::chrono::steady_clock::time_point object
         */
        auto GetStop();

        /**
         * @brief Returns the elapsed time in seconds
         * @return std::chrono::duration object
         */
        std::chrono::duration<double> Elapsed() const;

    private:

        /// @brief Start time
        std::chrono::steady_clock::time_point _start;

        /// @brief End time
        std::chrono::steady_clock::time_point _end;
    };

    inline
    auto Timer::GetStart()
    {
        return _start;
    }

    inline
    auto Timer::GetStop()
    {
        return _end;
    }
}
