/**
 * @file demo-server.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/http_server.hpp"
#include "http_server/http_file_request_handler.hpp"
#include "http_server/web_socket_request_handler.hpp"
#include "http_server/web_socket_frame_builder.hpp"

#include <memory>
#include <iostream>

using namespace http_server;

/**
 * @brief Echo all WebSocket frames back to the client
 */
class WebSocketEchoHandler : public WebSocketRequestHandler
{
protected:

    bool ProcessWebSocketFrame(const WebSocketFrameParser& frame_parser)
    {
        auto payload = frame_parser.Payload();

        for (size_t i = 0; i < payload.size(); i++)
        {
            std::cout << payload[i];
        }

        std::cout << std::endl;

        WebSocketFrameBuilder frame_builder(frame_parser.Opcode());
        frame_builder.SetPayload(payload);
        frame_builder.SendFrame(frame_parser.ClientFd());

        return true;
    }
};

/**
 *
 */
int main(int argc, char *argv[])
{
    (void) argc;
    (void) argv;

    auto server = HttpServer::CreateInstance();

    auto file_handler = std::make_shared<HttpFileRequestHandler>(std::filesystem::path("../examples/www/"));

    server->SetDefaultRequestHandler(file_handler);

    auto web_socket_handler = std::make_shared<WebSocketEchoHandler>();

    server->AddRequestHandler("/ws", web_socket_handler);

    auto t = server->Start();

    t.join();

    return 0;
}
