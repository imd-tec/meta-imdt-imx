/**
 * @file http_file_request_handler.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/http_file_request_handler.hpp"

#include <glog/logging.h>

#include <fstream>
#include <iostream>

using namespace http_server;
namespace fs = std::filesystem;

/*
 *
 *
 *
 */

/**
 *
 */
HttpFileRequestHandler::HttpFileRequestHandler(const std::filesystem::path& root_directory):
    _root_directory(root_directory)
{
}

/**
 *
 */
void HttpFileRequestHandler::HandleRequest(const HttpRequest& request,
                                           HttpResponse& response)
{
    const HttpUrl& request_url = request.RequestURL();

    LOG(INFO) << "Received " << request.RequestMethod() << " request for " << request_url.FullUrl() << std::endl;

    auto file_name_end = request_url.FullUrl().find("?");

    if (std::string::npos != file_name_end)
    {
        file_name_end -= 1;
    }

    // Skip the leading '/'
    /// @todo Check that the leading '/' exists first
    std::string file_name = request_url.FullUrl().substr(1, file_name_end);

    if (0 == file_name.size())
    {
        file_name = "index.html";
    }

    auto file_path = _root_directory;
    file_path /= file_name;

    if (fs::exists(file_path))
    {
        response.SetStatusCode(HttpStatusCode::k200OK);
        response.SetContent(file_path);

        std::string file_extension = file_path.extension().string();

        auto mime_type = _file_extension_table.find(file_extension);

        if (_file_extension_table.end() != mime_type)
        {
            response.SetContentType(mime_type->second);
        }
    }
    else
    {
        response.SetStatusCode(HttpStatusCode::k404NotFound);
    }

    response.SendToClient();
}

/*
 *
 *
 *
 */

std::map<std::string, MIMEContentType> HttpFileRequestHandler::_file_extension_table =
{
    { ".js", MIMEContentType::kApplicationJavascript },
    { ".raw", MIMEContentType::kApplicationOctetStream },
    { ".jpg", MIMEContentType::kImageJPEG },
    { ".jpeg", MIMEContentType::kImageJPEG },
    { ".png", MIMEContentType::kImagePNG },
    { ".svg", MIMEContentType::kImageSVGXML },
    { ".ico", MIMEContentType::kImageXIcon },
    { ".css", MIMEContentType::kTextCSS },
    { ".html", MIMEContentType::kTextHTML },
    { ".map", MIMEContentType::kApplicationJavascript },
};
