/**
 * @file http_server.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/http_server.hpp"
#include "http_server/http_client_connection.hpp"
#include "http_server/socket_file_descriptor.hpp"

#include <glog/logging.h>

#include <sys/socket.h>

#include <cstring>
#include <iostream>

using namespace http_server;

/*
 *
 *  HttpServer
 *
 */

/**
 * @details For more information on this approach, see
 * https://en.cppreference.com/w/cpp/memory/enable_shared_from_this#Example
 */
HttpServerSPtr HttpServer::CreateInstance(const uint16_t port_number)
{
    return std::shared_ptr<HttpServer>(new HttpServer(port_number));
}

/**
 *
 */
HttpServerSPtr HttpServer::GetSPtr()
{
    return shared_from_this();
}

/**
 *
 */
void HttpServer::SetDefaultRequestHandler(HttpRequestHandlerSPtr handler)
{
    _default_request_handler = handler;
}

/**
 *
 */
void HttpServer::AddRequestHandler(const std::string& route,
                                   HttpRequestHandlerSPtr handler)
{
    if (_request_handlers.end() != _request_handlers.find(route))
    {
        LOG(ERROR) << "Handler already exists for " << route;
        return;
    }

    _request_handlers[route] = handler;
}

/**
 *
 */
std::thread HttpServer::Start()
{
    if (_server_fd >= 0)
    {
        throw HttpServerException(HttpServerError::kAlreadyRunning);
    }

    CreateSocket();
    BindSocket();

    std::thread t = std::thread(&HttpServer::Run, this);

    return t;
}

/**
 *
 */
void HttpServer::HandleRequest(const HttpRequest& request,
                               HttpResponse& response)
{
    const std::string& route = request.RequestURL().Route();

    auto handler = _request_handlers.find(route);

    if (_request_handlers.end() != handler)
    {
        handler->second->HandleRequest(request, response);
        return;
    }

    if (nullptr == _default_request_handler)
    {
        LOG(ERROR) << "Default request handler hasn't been set";
        return;
    }

    _default_request_handler->HandleRequest(request, response);
}

/*
 *
 *  Private
 *
 */

/**
 *
 */
HttpServer::HttpServer(const uint16_t port_number):
    _port_number(port_number)
{
}

/**
 *
 */
void HttpServer::CreateSocket()
{
    // Create the main server socket

    _server_fd = socket(PF_INET, SOCK_STREAM, 0);

    if (_server_fd < 0)
    {
        throw HttpServerException(HttpServerError::kFailedToCreateSocket);
    }

    // Allow the address and port number to be reused

    int enable = 1;
    int r = setsockopt(_server_fd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int));

    if (r < 0)
    {
        throw HttpServerException(HttpServerError::kFailedToSetReuseAddrOption);
    }
}

/**
 *
 */
void HttpServer::BindSocket()
{
    // Bind to the specified port number

    (void) memset(&_server_address, 0, sizeof(struct sockaddr_in));

    _server_address.sin_family = AF_INET;
    _server_address.sin_port = htons(_port_number);
    _server_address.sin_addr.s_addr = INADDR_ANY;

    int r = bind(_server_fd, (struct sockaddr *)&_server_address, sizeof(_server_address));

    if (r < 0)
    {
        throw HttpServerException(HttpServerError::kFailedToBindSocket);
    }
}

/**
 *
 */
void HttpServer::Run()
{
    while (true)
    {
        Listen();
    }
}

/**
 *
 */
void HttpServer::Listen()
{
    int r = listen(_server_fd, 128);

    if (r < 0)
    {
        throw HttpServerException(HttpServerError::kFailedToListenForClientConnection);
    }

    struct sockaddr_in client_address;

    socklen_t address_length = sizeof(client_address);

    int fd = accept(_server_fd, (struct sockaddr *)&client_address, &address_length);

    if (fd < 0)
    {
        throw HttpServerException(HttpServerError::kFailedToAcceptClientConnection);
    }

    auto client_fd = std::make_shared<SocketFileDescriptor>(fd);

    std::thread t(StartClientConnection, GetSPtr(), client_fd, client_address);
    t.detach();
}

/*
 *
 *  HttpServerException
 *
 */

/**
 *
 */
HttpServerException::HttpServerException(const HttpServerError error_code):
    _error_code(error_code)
{
}

