/**
 * @file web_socket_frame_parser.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/web_socket_frame_parser.hpp"
#include "http_server/web_socket_constants.hpp"

#include <netinet/in.h>
#include <unistd.h>

#include <cstdint>
#include <cstring>
#include <iostream>

using namespace http_server;

/*
 *
 *
 *
 */

/**
 *
 */
WebSocketFrameParser::WebSocketFrameParser(SocketFileDescriptorSPtr client_fd):
    _client_fd(client_fd)
{
}

/**
 *
 * 0                   1                   2                   3
 * 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 * +-+-+-+-+-------+-+-------------+-------------------------------+
 * |F|R|R|R| opcode|M| Payload len |    Extended payload length    |
 * |I|S|S|S|  (4)  |A|     (7)     |             (16/64)           |
 * |N|V|V|V|       |S|             |   (if payload len==126/127)   |
 * | |1|2|3|       |K|             |                               |
 * +-+-+-+-+-------+-+-------------+ - - - - - - - - - - - - - - - +
 * |     Extended payload length continued, if payload len == 127  |
 * + - - - - - - - - - - - - - - - +-------------------------------+
 * |                               |Masking-key, if MASK set to 1  |
 * +-------------------------------+-------------------------------+
 * | Masking-key (continued)       |          Payload Data         |
 * +-------------------------------- - - - - - - - - - - - - - - - +
 * :                     Payload Data continued ...                :
 * + - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - +
 * |                     Payload Data continued ...                |
 * +---------------------------------------------------------------+
 *
 */
void WebSocketFrameParser::ReceiveFrame()
{
    char network_buffer[1024];
    memset(network_buffer, 0, sizeof(network_buffer));

    // Read the first two bytes

    ssize_t n = read(_client_fd->Get(), network_buffer, 2);

    if (n <= 0)
    {
        throw WebSocketFrameParserException(WebSocketFrameParserError::kClientHungUp);
    }

    _final_fragment = (network_buffer[0] & 0x80);
    _opcode = (network_buffer[0] & 0x0F);
    _masked_payload = (network_buffer[1] & 0x80);

    // Payload length

    _payload_length = (network_buffer[1] & 0x7F);

    if (kTwoBytePayloadLengthMarker == _payload_length)
    {
        uint16_t two_byte_payload_length = 0;

        int n = read(_client_fd->Get(), &two_byte_payload_length, sizeof(uint16_t));

        if (n <= 0)
        {
            throw WebSocketFrameParserException(WebSocketFrameParserError::kClientHungUp);
        }

        _payload_length = ntohs(two_byte_payload_length);
    }
    else if (kEightBytePayloadLengthMarker == _payload_length)
    {
        uint32_t eight_byte_payload_msw = 0;
        uint32_t eight_byte_payload_lsw = 0;

        n = read(_client_fd->Get(), &eight_byte_payload_msw, sizeof(uint32_t));

        if (n <= 0)
        {
            throw WebSocketFrameParserException(WebSocketFrameParserError::kClientHungUp);
        }

        n = read(_client_fd->Get(), &eight_byte_payload_lsw, sizeof(uint32_t));

        if (n <= 0)
        {
            throw WebSocketFrameParserException(WebSocketFrameParserError::kClientHungUp);
        }

        eight_byte_payload_msw = ntohl(eight_byte_payload_msw);
        eight_byte_payload_lsw = ntohl(eight_byte_payload_lsw);

        _payload_length = (static_cast<uint64_t>(eight_byte_payload_msw) << 32) |
                            eight_byte_payload_lsw;
    }

    // Mask

    if (_masked_payload)
    {
        n = read(_client_fd->Get(), &_mask, sizeof(_mask));

        if (n <= 0)
        {
            throw WebSocketFrameParserException(WebSocketFrameParserError::kClientHungUp);
        }
    }

    // Resize the payload container

    if (_payload_length > 0)
    {
        _payload.resize(_payload_length);
        uint8_t *payload_data = _payload.data();

        // Read the payload

        int64_t remaining = static_cast<int64_t>(_payload_length);
        const int64_t buffer_length = sizeof(network_buffer);

        while (remaining > 0)
        {
            memset(network_buffer, 0, sizeof(network_buffer));

            const int64_t read_length = (remaining > buffer_length) ? buffer_length : remaining;

            n = read(_client_fd->Get(), network_buffer, read_length);

            if (n <= 0)
            {
                throw WebSocketFrameParserException(WebSocketFrameParserError::kClientHungUp);
            }

            memcpy(payload_data, network_buffer, n);

            remaining -= n;
            payload_data += n;
        }

        // Unmask the payload

        uint8_t *mask_array = reinterpret_cast<uint8_t *>(&_mask);

        for (uint64_t i = 0; i < _payload_length; i++)
        {
            _payload[i] = static_cast<uint8_t>(_payload[i]) ^ mask_array[i % 4];
        }
    }
}

/*
 *
 *
 *
 */

/**
 *
 */
WebSocketFrameParserException::WebSocketFrameParserException(WebSocketFrameParserError error):
    _error(error)
{
}

/**
 *
 */
const char * WebSocketFrameParserException::what() const noexcept
{
    if (_error_descriptions.end() != _error_descriptions.find(_error))
    {
        return _error_descriptions[_error].c_str();
    }

    return "Unknown error";
}

/**
 *
 */
std::map<WebSocketFrameParserError, std::string> WebSocketFrameParserException::_error_descriptions =
{
    { WebSocketFrameParserError::kClientHungUp, "Client hung up" },
};
