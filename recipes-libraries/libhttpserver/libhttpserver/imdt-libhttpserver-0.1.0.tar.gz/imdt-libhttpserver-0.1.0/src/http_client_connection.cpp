/**
 * @file http_client_connection.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/http_client_connection.hpp"

#include "http_server/http_request.hpp"
#include "http_server/http_response.hpp"

#include <glog/logging.h>

#include <arpa/inet.h>
#include <sys/select.h>
#include <unistd.h>

#include <thread>
#include <cstring>
#include <sstream>
#include <iostream>

using namespace http_server;

/*
 *
 *
 *
 */

void http_server::StartClientConnection(HttpServerSPtr server,
                                        SocketFileDescriptorSPtr client_fd,
                                        struct sockaddr_in client_address)
{
    char ip_address[80];
    inet_ntop(AF_INET, &client_address.sin_addr, ip_address, sizeof(ip_address));

    LOG(INFO) << "Client connected [" << ip_address << ":" << ntohs(client_address.sin_port) << "]";

    HttpClientConnection connection(server, client_fd);

    connection.Run();

    LOG(INFO) << "Exiting thread";
}

/*
 *
 *
 *
 */

/**
 *
 */
HttpClientConnection::HttpClientConnection(HttpServerSPtr server,
                                           SocketFileDescriptorSPtr client_fd):
    _server(server),
    _client_fd(client_fd)
{

}

/**
 * @todo Consider adding support for persistent connections
 */
void HttpClientConnection::Run()
{
    std::stringstream request_buffer;

    while (true)
    {
        char network_buffer[128];
        memset(network_buffer, 0, sizeof(network_buffer));
        fd_set fds;

        FD_ZERO(&fds);
        FD_SET(_client_fd->Get(), &fds);

        int r = select(_client_fd->Get() + 1, &fds, NULL, NULL, NULL);

        if (r < 0)
        {
            /// @todo Replace this with a better exception and figure out where it could be caught
            throw std::exception();
        }

        // Read one less character than the buffer can hold to ensure it's null-terminated
        int n = read(_client_fd->Get(), network_buffer, sizeof(network_buffer) - 1);

        if (n == 0)
        {
            LOG(INFO) << "Client hung up";
            break;
        }

        // Append the buffer to the request
        request_buffer << network_buffer;

        // Check for the terminating "\r\n\r\n" sequence
        const auto pos = request_buffer.str().rfind("\r\n\r\n");

        if (std::string::npos != pos)
        {
            HttpRequest request(request_buffer.str());
            HttpResponse response(_client_fd);

            _server->HandleRequest(request, response);

            // Clear the buffer
            request_buffer.str(std::string());
            request_buffer.clear();

            // Close the connection and allow the thread to terminate
            close(_client_fd->Get());
            _client_fd->Invalidate();
            return;
        }
    }
}
