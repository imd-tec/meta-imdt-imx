/**
 * @file http_request.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/http_request.hpp"

#include <iostream>

using namespace http_server;

/*
 *
 *
 *
 */

/**
 *
 */
HttpRequest::HttpRequest(const std::string& http_request)
{
    // The first line is the request line

    auto line_end = http_request.find("\r\n");
    std::string request_line = http_request.substr(0, line_end);

    ParseRequestLine(request_line);

    // All other lines are field/value pairs

    auto line_start = line_end += 2;

    while ((line_end = http_request.find("\r\n", line_start)) != std::string::npos)
    {
        std::string line = http_request.substr(line_start, (line_end - line_start));
        line_start = line_end + 2;

        auto field_end = line.find(":");

        if (std::string::npos != field_end)
        {
            auto value_start = field_end + 1;
            if (line[value_start] == ' ')
            {
                value_start += 1;
            }

            std::string field = line.substr(0, field_end);
            std::string value = line.substr(value_start);

            _header_values[field] = value;
        }
    }
}

/*
 *
 *
 *
 */

/**
 *
 */
void HttpRequest::ParseRequestLine(const std::string& request_line)
{
    auto method_end = request_line.find(" ");

    _request_method = request_line.substr(0, method_end);

    auto url_start = method_end + 1;
    auto url_end = request_line.find(" ", url_start);

    _request_url.SetUrl(request_line.substr(url_start, (url_end - url_start)));

    auto protocol_start = url_end + 1;

    _protocol_version = request_line.substr(protocol_start);
}
