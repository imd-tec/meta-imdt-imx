/**
 * @file http_request_handler.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/http_request_handler.hpp"

using namespace http_server;

/*
 *
 *
 *
 */

/**
 *
 */
HttpRequestHandler::~HttpRequestHandler()
{
}
