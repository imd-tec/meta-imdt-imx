/**
 * @file http_url.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include <string>

namespace http_server
{
    /**
     * @brief Parses an HTTP URL
     */
    class HttpUrl
    {
    public:

        /**
         * @brief Default constructor
         */
        HttpUrl();

        /**
         * @brief Constructs the object and parses the given URL
         * @param url HTTP URL
         */
        explicit HttpUrl(const std::string& url);

        /**
         * @brief Parses the given URL
         * @param url HTTP URL
         */
        void SetUrl(const std::string& url);

        /**
         * @brief Checks if the URL is valid
         * @return
         */
        bool IsValid() const;

        /**
         * @brief Returns the full URL
         * @return
         */
        const std::string& FullUrl() const;

        /**
         * @brief Returns the "route" portion of the URL
         * @return
         */
        const std::string& Route() const;

    private:

        /**
         * @brief Parses the URL
         * @param url HTTP URL
         */
        void ParseUrl(const std::string& url);

        /// @brief Is valid flag
        bool _is_valid { false };

        /// @brief The full URL
        std::string _full_url;

        /// @brief The "route" portion of the URL
        std::string _route;

    };

    inline
    bool HttpUrl::IsValid() const
    {
        return _is_valid;
    }

    inline
    const std::string& HttpUrl::FullUrl() const
    {
        return _full_url;
    }

    inline
    const std::string& HttpUrl::Route() const
    {
        return _route;
    }
}
