/**
 * @file web_socket_frame_builder.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/socket_file_descriptor.hpp"

#include <cstdint>
#include <vector>

namespace http_server
{
    /**
     * @brief Build a WebSocket frame
     */
    class WebSocketFrameBuilder
    {
    public:

        /**
         * @brief Constructor
         * @param opcode Frame opcode
         */
        explicit WebSocketFrameBuilder(const uint8_t opcode);

        /**
         * @brief Set the frame's payload
         * @param payload Vector of bytes
         */
        void SetPayload(const std::vector<uint8_t>& payload);

        /**
         * @brief Set the frame's payload
         * @param payload String
         */
        void SetPayload(const std::string& payload);

        /**
         * @brief Send the frame to the client
         * @param client_fd Client socket file descriptor
         */
        void SendFrame(SocketFileDescriptorSPtr client_fd);

    private:

        /// @brief Frame opcode
        uint8_t _opcode;

        /// @brief Frame payload
        std::vector<uint8_t> _payload;

    };
}
