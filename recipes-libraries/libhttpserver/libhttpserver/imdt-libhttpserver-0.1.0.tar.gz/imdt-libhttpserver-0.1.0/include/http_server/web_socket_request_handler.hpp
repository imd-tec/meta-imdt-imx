/**
 * @file web_socket_request_handler.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/http_request_handler.hpp"
#include "http_server/web_socket_frame_parser.hpp"

#include <cstdint>

namespace http_server
{
    /**
     * @brief WebSocket request handler
     */
    class WebSocketRequestHandler : public HttpRequestHandler
    {
    public:

        virtual ~WebSocketRequestHandler();

        /**
         * @brief Handle WebSocket requests
         * @param request HTTP "Upgrade" request
         * @param response HTTP response
         */
        void HandleRequest(const HttpRequest& request,
                           HttpResponse& response);

    protected:

        /**
         * @brief Process a WebSocket frame
         * @param frame_parser Parsed WebSocket frame
         * @return True if the WebSocket connection should persist, false if it should be closed
         */
        [[nodiscard]]
        virtual bool ProcessWebSocketFrame(const WebSocketFrameParser& frame_parser) = 0;

    private:

    };
}
