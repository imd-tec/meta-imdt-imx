/**
 * @file http_server.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/http_request_handler.hpp"
#include "http_server/http_request.hpp"
#include "http_server/http_response.hpp"

#include <netinet/in.h>

#include <exception>
#include <map>
#include <memory>
#include <thread>
#include <cstdint>

namespace http_server
{
    class HttpServer;
    using HttpServerSPtr = std::shared_ptr<HttpServer>;

    enum class HttpServerError;
    class HttpServerException;

    class HttpServer : public std::enable_shared_from_this<HttpServer>
    {
    public:

        /**
         * @brief Create an instance of HttpServer, wrapped in a shared_ptr
         * @param port_number Optional TCP port number (defaults to 8080)
         * @return HttpServer instance, wrapped in a shared_ptr
         *
         * @details This class does not follow the Singleton pattern. Multiple
         * instances can be created by repeatedly calling CreateInstance()
         */
        [[nodiscard]]
        static HttpServerSPtr CreateInstance(const uint16_t port_number = 8080);

        /**
         * @brief Get a shared_ptr for this instance of HttpServer
         * @return
         */
        HttpServerSPtr GetSPtr();

        /**
         * @brief Set the default request handler
         * @param handler Request handler shared_ptr
         */
        void SetDefaultRequestHandler(HttpRequestHandlerSPtr handler);

        /**
         * @brief Add a request handler
         * @param route The route for to this handler (e.g., "/ws")
         * @param handler Request handler shared_ptr
         */
        void AddRequestHandler(const std::string& route,
                               HttpRequestHandlerSPtr handler);

        /**
         * @brief Start the Http server
         * @return
         */
        std::thread Start();

        /**
         * @brief Handle a request
         * @param request The request from the client
         */
        void HandleRequest(const HttpRequest& request,
                           HttpResponse& response);

        /**
         * @brief Get the TCP port number
         * @return TCP port number
         */
        uint16_t PortNumber() const;

    private:

        /**
         * @brief Constructor
         * @param port_number TCP port to listen on
         */
        HttpServer(const uint16_t port_number);

        /**
         * @brief Create the main server socket
         */
        void CreateSocket();

        /**
         * @brief Bind the server socket to the requested port number
         */
        void BindSocket();

        /**
         * @brief Run the main loop
         * @details This happens in a separate thread
         */
        void Run();

        /**
         * @brief Listen for client connections
         * @details Each client connection is handled in a separate thread,
         * which persists until the client hangs up
         */
        void Listen();

        static constexpr int InvalidFileDescriptor { -1 };

        /// @brief TCP port that this server listens on
        uint16_t _port_number;

        /// @brief Server socket file descriptor
        int _server_fd { InvalidFileDescriptor };

        /// @brief Server address
        struct sockaddr_in _server_address;

        /// @brief Default handler for HTTP requests
        HttpRequestHandlerSPtr _default_request_handler { nullptr };

        /// @brief Map of route mnemonics and request handlers
        std::map<std::string, HttpRequestHandlerSPtr> _request_handlers;
    };

    inline
    uint16_t HttpServer::PortNumber() const
    {
        return _port_number;
    }

    enum class HttpServerError
    {
        kAlreadyRunning,
        kFailedToCreateSocket,
        kFailedToSetReuseAddrOption,
        kFailedToBindSocket,
        kFailedToListenForClientConnection,
        kFailedToAcceptClientConnection,

    };

    class HttpServerException : public std::exception
    {
    public:

        explicit HttpServerException(const HttpServerError error_code);

    private:

        HttpServerError _error_code;
    };
}
