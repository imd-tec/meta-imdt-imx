/**
 * @file http_file_request_handler.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/http_request_handler.hpp"

#include <filesystem>
#include <map>
#include <string>

namespace http_server
{
    /**
     * @brief Simple static file handler
     */
    class HttpFileRequestHandler : public HttpRequestHandler
    {
    public:

        /**
         * @brief Constructor
         * @param root_directory Root directory for this handler
         */
        explicit HttpFileRequestHandler(const std::filesystem::path& root_directory);

        /**
         * @brief Handle a request from a client
         * @param request HTTP request
         * @param response Container for the response
         */
        void HandleRequest(const HttpRequest& request,
                           HttpResponse& response);

    private:

        /// @brief Path to the directory containing the static files
        const std::filesystem::path _root_directory;

        /// @brief Map of filename extensions and MIME content types
        static std::map<std::string, MIMEContentType> _file_extension_table;
    };
}
