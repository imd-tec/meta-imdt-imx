/**
 * @file web_socket_frame_parser.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/socket_file_descriptor.hpp"

#include <exception>
#include <cstdint>
#include <vector>
#include <map>

namespace http_server
{
    /**
     * @brief WebSocket frame parser
     */
    class WebSocketFrameParser
    {
    public:

        /**
         * @brief Constructor
         * @param client_fd Client file descriptor
         */
        explicit WebSocketFrameParser(SocketFileDescriptorSPtr client_fd);

        /**
         * @brief Access the client connection file descriptor
         * @return
         */
        SocketFileDescriptorSPtr ClientFd() const;

        /**
         * @brief Receive and parse a WebSocket frame
         */
        void ReceiveFrame();

        /**
         * @brief Get the opcode for the received frame
         * @return
         */
        uint8_t Opcode() const;

        /**
         * @brief Access the frame's payload
         * @return
         */
        const std::vector<uint8_t> Payload() const;

        /**
         * @brief Get the payload length
         * @return
         */
        uint64_t PayloadLength() const;

    private:

        /// @brief Client connection file descriptor
        SocketFileDescriptorSPtr _client_fd;

        /// @brief Final fragment flag
        bool _final_fragment { false };

        /// @brief WebSocket opcode
        uint8_t _opcode { 0U };

        /// @brief Masked payload flag
        bool _masked_payload { false };

        /// @brief Payload length
        uint64_t _payload_length { 0U };

        /// @brief Mask value
        uint32_t _mask { 0U };

        /// @brief Unmasked payload data
        std::vector<uint8_t> _payload;
    };

    inline
    SocketFileDescriptorSPtr WebSocketFrameParser::ClientFd() const
    {
        return _client_fd;
    }

    inline
    uint8_t WebSocketFrameParser::Opcode() const
    {
        return _opcode;
    }

    inline
    const std::vector<uint8_t> WebSocketFrameParser::Payload() const
    {
        return _payload;
    }

    inline
    uint64_t WebSocketFrameParser::PayloadLength() const
    {
        return _payload_length;
    }

    enum class WebSocketFrameParserError;

    /**
     * @brief WebSocket frame parser exception
     */
    class WebSocketFrameParserException : public std::exception
    {
    public:

        /**
         * @brief Constructor
         * @param error Error code
         */
        explicit WebSocketFrameParserException(WebSocketFrameParserError error);

        /**
         * @brief Returns the error code
         * @return
         */
        WebSocketFrameParserError GetError() const;

        /**
         * @brief Access a description of the exception
         * @return
         */
        const char * what() const noexcept;

    private:

        /// @brief Error code
        WebSocketFrameParserError _error;

        /// @brief Map of error codes and descriptions
        static std::map<WebSocketFrameParserError, std::string> _error_descriptions;
    };

    inline
    WebSocketFrameParserError WebSocketFrameParserException::GetError() const
    {
        return _error;
    }

    enum class WebSocketFrameParserError
    {
        kClientHungUp,
    };
}
